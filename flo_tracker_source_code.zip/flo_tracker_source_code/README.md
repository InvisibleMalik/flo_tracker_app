# Flo Tracker - Period & Ovulation Tracker App

This repository contains a complete hybrid full stack app for both Android and iOS, similar to the Flo Period & Ovulation Tracker app. The app is built using Flutter and follows the MVVM architecture pattern.

## Features

- **Period Tracking**: Log and predict menstrual cycles
- **Symptom Logging**: Track 70+ symptoms throughout your cycle
- **Fertility Tracking**: Monitor fertile window and ovulation
- **Partner Sharing**: Share cycle information with partners
- **Privacy Protection**: Secure data with encryption and anonymous mode
- **Customizable Reminders**: Never miss tracking important cycle events
- **Insights & Reports**: View personalized insights about cycle patterns
- **Cross-Platform**: Works on both Android and iOS devices

## Project Structure

```
flo_tracker/
├── assets/
│   ├── icons/           # App icons for Android and iOS
│   └── images/          # Images used in the app
├── lib/
│   ├── config/          # App configuration
│   ├── models/          # Data models
│   ├── repositories/    # Data repositories
│   ├── services/        # Business logic services
│   ├── ui/              # UI components
│   │   ├── screens/     # App screens
│   │   ├── widgets/     # Reusable widgets
│   │   └── dialogs/     # Dialog components
│   ├── utils/           # Utility functions
│   ├── viewmodels/      # View models for MVVM pattern
│   ├── app.dart         # App entry point
│   └── main.dart        # Main entry point
└── docs/                # Documentation
    ├── database_schema.md
    ├── api_endpoints.md
    ├── navigation_flow.md
    └── component_architecture.md
```

## Architecture

The app follows the MVVM (Model-View-ViewModel) architecture pattern:

- **Models**: Data structures representing the app's data
- **Views**: UI components (screens, widgets)
- **ViewModels**: Connect the UI with the business logic
- **Services**: Handle business logic and data operations
- **Repositories**: Abstract data sources (local database, API)

## Technical Stack

- **Frontend**: Flutter
- **State Management**: Provider
- **Local Database**: SQLite with sqflite
- **Authentication**: Firebase Auth
- **Cloud Storage**: Firebase Firestore (optional)
- **Analytics**: Firebase Analytics (optional)

## Getting Started

### Prerequisites

- Flutter SDK
- Android Studio / Xcode
- Firebase account (for authentication)

### Installation

1. Clone the repository
2. Install dependencies:
   ```
   flutter pub get
   ```
3. Run the app:
   ```
   flutter run
   ```

## Building for Production

### Android

```
flutter build apk --release
```

The APK will be available at `build/app/outputs/flutter-apk/app-release.apk`

### iOS

```
flutter build ios --release
```

Then open the Xcode project and archive it for App Store submission.

## App Store Submission

See the [App Store Submission Guide](app_store_submission_guide.md) for detailed instructions on submitting the app to both the Apple App Store and Google Play Store.

## License

This project is licensed under the MIT License - see the LICENSE file for details.

## Acknowledgements

- Flo app for inspiration
- Flutter team for the amazing framework
- All contributors to the open-source packages used in this project
