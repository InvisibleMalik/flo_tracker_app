import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flo_tracker/app.dart';
import 'package:flo_tracker/viewmodels/auth_viewmodel.dart';
import 'package:flo_tracker/viewmodels/cycle_viewmodel.dart';
import 'package:flo_tracker/viewmodels/symptom_viewmodel.dart';
import 'package:flo_tracker/viewmodels/fertility_viewmodel.dart';
import 'package:flo_tracker/viewmodels/theme_viewmodel.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  
  // Initialize Firebase
  await Firebase.initializeApp();
  
  // Initialize view models
  final authViewModel = AuthViewModel();
  await authViewModel.initialize();
  
  final cycleViewModel = CycleViewModel();
  final symptomViewModel = SymptomViewModel();
  final fertilityViewModel = FertilityViewModel();
  final themeViewModel = ThemeViewModel();
  
  // Initialize other view models if user is authenticated
  if (authViewModel.status == AuthStatus.authenticated) {
    await cycleViewModel.initialize();
    await symptomViewModel.initialize();
    await fertilityViewModel.initialize();
  }
  
  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider<AuthViewModel>.value(value: authViewModel),
        ChangeNotifierProvider<CycleViewModel>.value(value: cycleViewModel),
        ChangeNotifierProvider<SymptomViewModel>.value(value: symptomViewModel),
        ChangeNotifierProvider<FertilityViewModel>.value(value: fertilityViewModel),
        ChangeNotifierProvider<ThemeViewModel>.value(value: themeViewModel),
      ],
      child: const App(),
    ),
  );
}
