import 'package:uuid/uuid.dart';

class Cycle {
  final String id;
  final String userId;
  final DateTime startDate;
  final DateTime? endDate;
  final String? notes;
  final bool isPrediction;

  Cycle({
    String? id,
    required this.userId,
    required this.startDate,
    this.endDate,
    this.notes,
    this.isPrediction = false,
  }) : id = id ?? const Uuid().v4();

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'user_id': userId,
      'start_date': startDate.millisecondsSinceEpoch,
      'end_date': endDate?.millisecondsSinceEpoch,
      'notes': notes,
      'is_prediction': isPrediction ? 1 : 0,
    };
  }

  factory Cycle.fromMap(Map<String, dynamic> map) {
    return Cycle(
      id: map['id'],
      userId: map['user_id'],
      startDate: DateTime.fromMillisecondsSinceEpoch(map['start_date']),
      endDate: map['end_date'] != null
          ? DateTime.fromMillisecondsSinceEpoch(map['end_date'])
          : null,
      notes: map['notes'],
      isPrediction: map['is_prediction'] == 1,
    );
  }

  Cycle copyWith({
    String? userId,
    DateTime? startDate,
    DateTime? endDate,
    String? notes,
    bool? isPrediction,
  }) {
    return Cycle(
      id: this.id,
      userId: userId ?? this.userId,
      startDate: startDate ?? this.startDate,
      endDate: endDate ?? this.endDate,
      notes: notes ?? this.notes,
      isPrediction: isPrediction ?? this.isPrediction,
    );
  }

  int get durationInDays {
    if (endDate == null) {
      // If cycle is ongoing, calculate duration until today
      final today = DateTime.now();
      return today.difference(startDate).inDays + 1;
    }
    return endDate!.difference(startDate).inDays + 1;
  }
}
