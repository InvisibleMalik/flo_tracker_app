import 'package:uuid/uuid.dart';

class User {
  final String id;
  final String? name;
  final String? email;
  final DateTime createdAt;
  final DateTime lastLogin;
  final bool isAnonymous;
  final int cycleLength;
  final int periodLength;
  final bool premiumStatus;

  User({
    String? id,
    this.name,
    this.email,
    DateTime? createdAt,
    DateTime? lastLogin,
    this.isAnonymous = false,
    this.cycleLength = 28,
    this.periodLength = 5,
    this.premiumStatus = false,
  })  : id = id ?? const Uuid().v4(),
        createdAt = createdAt ?? DateTime.now(),
        lastLogin = lastLogin ?? DateTime.now();

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'name': name,
      'email': email,
      'created_at': createdAt.millisecondsSinceEpoch,
      'last_login': lastLogin.millisecondsSinceEpoch,
      'is_anonymous': isAnonymous ? 1 : 0,
      'cycle_length': cycleLength,
      'period_length': periodLength,
      'premium_status': premiumStatus ? 1 : 0,
    };
  }

  factory User.fromMap(Map<String, dynamic> map) {
    return User(
      id: map['id'],
      name: map['name'],
      email: map['email'],
      createdAt: DateTime.fromMillisecondsSinceEpoch(map['created_at']),
      lastLogin: DateTime.fromMillisecondsSinceEpoch(map['last_login']),
      isAnonymous: map['is_anonymous'] == 1,
      cycleLength: map['cycle_length'] ?? 28,
      periodLength: map['period_length'] ?? 5,
      premiumStatus: map['premium_status'] == 1,
    );
  }

  User copyWith({
    String? name,
    String? email,
    DateTime? lastLogin,
    bool? isAnonymous,
    int? cycleLength,
    int? periodLength,
    bool? premiumStatus,
  }) {
    return User(
      id: this.id,
      name: name ?? this.name,
      email: email ?? this.email,
      createdAt: this.createdAt,
      lastLogin: lastLogin ?? this.lastLogin,
      isAnonymous: isAnonymous ?? this.isAnonymous,
      cycleLength: cycleLength ?? this.cycleLength,
      periodLength: periodLength ?? this.periodLength,
      premiumStatus: premiumStatus ?? this.premiumStatus,
    );
  }
}
