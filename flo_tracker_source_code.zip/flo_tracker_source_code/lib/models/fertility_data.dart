import 'package:uuid/uuid.dart';

class FertilityData {
  final String id;
  final String userId;
  final DateTime date;
  final double? basalBodyTemperature;
  final String? cervicalMucusType;
  final String? ovulationTestResult;
  final bool isFertileDay;
  final bool isOvulationDay;
  final String? notes;

  FertilityData({
    String? id,
    required this.userId,
    required this.date,
    this.basalBodyTemperature,
    this.cervicalMucusType,
    this.ovulationTestResult,
    this.isFertileDay = false,
    this.isOvulationDay = false,
    this.notes,
  }) : id = id ?? const Uuid().v4();

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'user_id': userId,
      'date': date.millisecondsSinceEpoch,
      'basal_body_temperature': basalBodyTemperature,
      'cervical_mucus_type': cervicalMucusType,
      'ovulation_test_result': ovulationTestResult,
      'is_fertile_day': isFertileDay ? 1 : 0,
      'is_ovulation_day': isOvulationDay ? 1 : 0,
      'notes': notes,
    };
  }

  factory FertilityData.fromMap(Map<String, dynamic> map) {
    return FertilityData(
      id: map['id'],
      userId: map['user_id'],
      date: DateTime.fromMillisecondsSinceEpoch(map['date']),
      basalBodyTemperature: map['basal_body_temperature'],
      cervicalMucusType: map['cervical_mucus_type'],
      ovulationTestResult: map['ovulation_test_result'],
      isFertileDay: map['is_fertile_day'] == 1,
      isOvulationDay: map['is_ovulation_day'] == 1,
      notes: map['notes'],
    );
  }

  FertilityData copyWith({
    String? userId,
    DateTime? date,
    double? basalBodyTemperature,
    String? cervicalMucusType,
    String? ovulationTestResult,
    bool? isFertileDay,
    bool? isOvulationDay,
    String? notes,
  }) {
    return FertilityData(
      id: this.id,
      userId: userId ?? this.userId,
      date: date ?? this.date,
      basalBodyTemperature: basalBodyTemperature ?? this.basalBodyTemperature,
      cervicalMucusType: cervicalMucusType ?? this.cervicalMucusType,
      ovulationTestResult: ovulationTestResult ?? this.ovulationTestResult,
      isFertileDay: isFertileDay ?? this.isFertileDay,
      isOvulationDay: isOvulationDay ?? this.isOvulationDay,
      notes: notes ?? this.notes,
    );
  }
}
