class Symptom {
  final String id;
  final String name;
  final String category;
  final String? description;
  final bool isPremium;

  Symptom({
    required this.id,
    required this.name,
    required this.category,
    this.description,
    this.isPremium = false,
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'name': name,
      'category': category,
      'description': description,
      'is_premium': isPremium ? 1 : 0,
    };
  }

  factory Symptom.fromMap(Map<String, dynamic> map) {
    return Symptom(
      id: map['id'],
      name: map['name'],
      category: map['category'],
      description: map['description'],
      isPremium: map['is_premium'] == 1,
    );
  }

  Symptom copyWith({
    String? name,
    String? category,
    String? description,
    bool? isPremium,
  }) {
    return Symptom(
      id: this.id,
      name: name ?? this.name,
      category: category ?? this.category,
      description: description ?? this.description,
      isPremium: isPremium ?? this.isPremium,
    );
  }
}
