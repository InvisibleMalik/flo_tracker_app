import 'package:uuid/uuid.dart';

class UserSymptom {
  final String id;
  final String userId;
  final String symptomId;
  final DateTime date;
  final int? intensity;
  final String? notes;
  
  // Additional fields for UI display
  String? symptomName;
  String? category;

  UserSymptom({
    String? id,
    required this.userId,
    required this.symptomId,
    required this.date,
    this.intensity,
    this.notes,
    this.symptomName,
    this.category,
  }) : id = id ?? const Uuid().v4();

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'user_id': userId,
      'symptom_id': symptomId,
      'date': date.millisecondsSinceEpoch,
      'intensity': intensity,
      'notes': notes,
    };
  }

  factory UserSymptom.fromMap(Map<String, dynamic> map) {
    return UserSymptom(
      id: map['id'],
      userId: map['user_id'],
      symptomId: map['symptom_id'],
      date: DateTime.fromMillisecondsSinceEpoch(map['date']),
      intensity: map['intensity'],
      notes: map['notes'],
    );
  }

  UserSymptom copyWith({
    String? userId,
    String? symptomId,
    DateTime? date,
    int? intensity,
    String? notes,
    String? symptomName,
    String? category,
  }) {
    return UserSymptom(
      id: this.id,
      userId: userId ?? this.userId,
      symptomId: symptomId ?? this.symptomId,
      date: date ?? this.date,
      intensity: intensity ?? this.intensity,
      notes: notes ?? this.notes,
      symptomName: symptomName ?? this.symptomName,
      category: category ?? this.category,
    );
  }
}
