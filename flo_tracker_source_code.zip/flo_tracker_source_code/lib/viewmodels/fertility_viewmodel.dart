import 'package:flutter/material.dart';
import 'package:flo_tracker/services/fertility_service.dart';
import 'package:flo_tracker/models/fertility_data.dart';
import 'package:flo_tracker/services/auth_service.dart';

class FertilityViewModel extends ChangeNotifier {
  final FertilityService _fertilityService = FertilityService();
  final AuthService _authService = AuthService();
  
  bool _isLoading = false;
  bool get isLoading => _isLoading;
  
  String? _errorMessage;
  String? get errorMessage => _errorMessage;
  
  List<FertilityData> _fertilityData = [];
  List<FertilityData> get fertilityData => _fertilityData;
  
  List<FertilityData> _fertilityPredictions = [];
  List<FertilityData> get fertilityPredictions => _fertilityPredictions;
  
  bool get isTodayFertileDay => _fertilityService.isTodayFertileDay;
  bool get isTodayOvulationDay => _fertilityService.isTodayOvulationDay;
  
  FertilityViewModel() {
    _fertilityService.fertilityDataChanges.listen((data) {
      _fertilityData = data;
      notifyListeners();
    });
  }
  
  Future<void> initialize() async {
    if (_authService.currentUser == null) {
      _errorMessage = 'No user logged in';
      notifyListeners();
      return;
    }
    
    _setLoading(true);
    await _fertilityService.initialize();
    _fertilityData = _fertilityService.fertilityData;
    _fertilityPredictions = _fertilityService.fertilityPredictions;
    _errorMessage = _fertilityService.errorMessage;
    _setLoading(false);
  }
  
  Future<bool> logFertilityData(
    DateTime date, {
    double? basalBodyTemperature,
    String? cervicalMucusType,
    String? ovulationTestResult,
    String? notes,
  }) async {
    _setLoading(true);
    final result = await _fertilityService.logFertilityData(
      date,
      basalBodyTemperature: basalBodyTemperature,
      cervicalMucusType: cervicalMucusType,
      ovulationTestResult: ovulationTestResult,
      notes: notes,
    );
    _errorMessage = _fertilityService.errorMessage;
    _setLoading(false);
    return result;
  }
  
  FertilityData? getFertilityDataForDate(DateTime date) {
    return _fertilityService.getFertilityDataForDate(date);
  }
  
  void _setLoading(bool loading) {
    _isLoading = loading;
    notifyListeners();
  }
  
  void clearError() {
    _errorMessage = null;
    notifyListeners();
  }
}
