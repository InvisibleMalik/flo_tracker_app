import 'package:flutter/material.dart';
import 'package:flo_tracker/services/auth_service.dart';
import 'package:flo_tracker/models/user.dart' as app_models;

enum AuthStatus {
  initial,
  authenticating,
  authenticated,
  unauthenticated,
  error,
}

class AuthViewModel extends ChangeNotifier {
  final AuthService _authService = AuthService();
  
  AuthStatus _status = AuthStatus.initial;
  AuthStatus get status => _status;
  
  app_models.User? _user;
  app_models.User? get user => _user;
  
  String? _errorMessage;
  String? get errorMessage => _errorMessage;
  
  AuthViewModel() {
    _authService.authStateChanges.listen((status) {
      _status = status;
      _user = _authService.currentUser;
      notifyListeners();
    });
  }
  
  Future<void> initialize() async {
    await _authService.initialize();
    _status = _authService.status;
    _user = _authService.currentUser;
    _errorMessage = _authService.errorMessage;
    notifyListeners();
  }
  
  Future<bool> register(String email, String password, String name) async {
    final result = await _authService.registerWithEmailAndPassword(email, password, name);
    _errorMessage = _authService.errorMessage;
    _user = _authService.currentUser;
    notifyListeners();
    return result;
  }
  
  Future<bool> login(String email, String password) async {
    final result = await _authService.loginWithEmailAndPassword(email, password);
    _errorMessage = _authService.errorMessage;
    _user = _authService.currentUser;
    notifyListeners();
    return result;
  }
  
  Future<bool> loginAnonymously() async {
    final result = await _authService.loginAnonymously();
    _errorMessage = _authService.errorMessage;
    _user = _authService.currentUser;
    notifyListeners();
    return result;
  }
  
  Future<bool> convertAnonymousAccount(String email, String password, String name) async {
    final result = await _authService.convertAnonymousAccount(email, password, name);
    _errorMessage = _authService.errorMessage;
    _user = _authService.currentUser;
    notifyListeners();
    return result;
  }
  
  Future<void> logout() async {
    await _authService.logout();
    _user = null;
    notifyListeners();
  }
  
  Future<bool> updateUserProfile({
    String? name,
    int? cycleLength,
    int? periodLength,
  }) async {
    final result = await _authService.updateUserProfile(
      name: name,
      cycleLength: cycleLength,
      periodLength: periodLength,
    );
    _errorMessage = _authService.errorMessage;
    _user = _authService.currentUser;
    notifyListeners();
    return result;
  }
  
  Future<bool> resetPassword(String email) async {
    final result = await _authService.resetPassword(email);
    _errorMessage = _authService.errorMessage;
    notifyListeners();
    return result;
  }
  
  void clearError() {
    _errorMessage = null;
    notifyListeners();
  }
}
