import 'package:flutter/material.dart';
import 'package:flo_tracker/services/cycle_service.dart';
import 'package:flo_tracker/models/cycle.dart';
import 'package:flo_tracker/services/auth_service.dart';

class CycleViewModel extends ChangeNotifier {
  final CycleService _cycleService = CycleService();
  final AuthService _authService = AuthService();
  
  bool _isLoading = false;
  bool get isLoading => _isLoading;
  
  String? _errorMessage;
  String? get errorMessage => _errorMessage;
  
  List<Cycle> _cycles = [];
  List<Cycle> get cycles => _cycles;
  
  Cycle? _currentCycle;
  Cycle? get currentCycle => _currentCycle;
  
  List<Cycle> _predictions = [];
  List<Cycle> get predictions => _predictions;
  
  bool get isTodayPeriodDay => _cycleService.isTodayPeriodDay;
  int get daysUntilNextPeriod => _cycleService.daysUntilNextPeriod;
  
  CycleViewModel() {
    _cycleService.cycleDataChanges.listen((cycles) {
      _cycles = cycles;
      _currentCycle = _cycleService.currentCycle;
      _predictions = _cycleService.predictions;
      notifyListeners();
    });
  }
  
  Future<void> initialize() async {
    if (_authService.currentUser == null) {
      _errorMessage = 'No user logged in';
      notifyListeners();
      return;
    }
    
    _setLoading(true);
    await _cycleService.initialize();
    _cycles = _cycleService.cycles;
    _currentCycle = _cycleService.currentCycle;
    _predictions = _cycleService.predictions;
    _errorMessage = _cycleService.errorMessage;
    _setLoading(false);
  }
  
  Future<bool> logPeriodStart(DateTime startDate, {String? notes}) async {
    _setLoading(true);
    final result = await _cycleService.logPeriodStart(startDate, notes: notes);
    _errorMessage = _cycleService.errorMessage;
    _setLoading(false);
    return result;
  }
  
  Future<bool> logPeriodEnd(String cycleId, DateTime endDate, {String? notes}) async {
    _setLoading(true);
    final result = await _cycleService.logPeriodEnd(cycleId, endDate, notes: notes);
    _errorMessage = _cycleService.errorMessage;
    _setLoading(false);
    return result;
  }
  
  void _setLoading(bool loading) {
    _isLoading = loading;
    notifyListeners();
  }
  
  void clearError() {
    _errorMessage = null;
    notifyListeners();
  }
}
