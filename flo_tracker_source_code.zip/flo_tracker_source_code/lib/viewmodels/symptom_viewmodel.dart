import 'package:flutter/material.dart';
import 'package:flo_tracker/services/symptom_service.dart';
import 'package:flo_tracker/models/symptom.dart';
import 'package:flo_tracker/models/user_symptom.dart';
import 'package:flo_tracker/services/auth_service.dart';

class SymptomViewModel extends ChangeNotifier {
  final SymptomService _symptomService = SymptomService();
  final AuthService _authService = AuthService();
  
  bool _isLoading = false;
  bool get isLoading => _isLoading;
  
  String? _errorMessage;
  String? get errorMessage => _errorMessage;
  
  List<Symptom> _symptoms = [];
  List<Symptom> get symptoms => _symptoms;
  
  Map<String, List<Symptom>> _symptomsByCategory = {};
  Map<String, List<Symptom>> get symptomsByCategory => _symptomsByCategory;
  
  List<UserSymptom> _userSymptoms = [];
  List<UserSymptom> get userSymptoms => _userSymptoms;
  
  SymptomViewModel() {
    _symptomService.symptomDataChanges.listen((symptoms) {
      _userSymptoms = symptoms;
      notifyListeners();
    });
  }
  
  Future<void> initialize() async {
    _setLoading(true);
    await _symptomService.initialize();
    _symptoms = _symptomService.symptoms;
    _symptomsByCategory = _symptomService.symptomsByCategory;
    _userSymptoms = _symptomService.userSymptoms;
    _errorMessage = _symptomService.errorMessage;
    _setLoading(false);
  }
  
  Future<bool> logSymptom(String symptomId, DateTime date, {int? intensity, String? notes}) async {
    _setLoading(true);
    final result = await _symptomService.logSymptom(
      symptomId,
      date,
      intensity: intensity,
      notes: notes,
    );
    _errorMessage = _symptomService.errorMessage;
    _setLoading(false);
    return result;
  }
  
  Future<bool> deleteSymptom(String userSymptomId) async {
    _setLoading(true);
    final result = await _symptomService.deleteSymptom(userSymptomId);
    _errorMessage = _symptomService.errorMessage;
    _setLoading(false);
    return result;
  }
  
  List<UserSymptom> getSymptomsForDate(DateTime date) {
    return _symptomService.getSymptomsForDate(date);
  }
  
  void _setLoading(bool loading) {
    _isLoading = loading;
    notifyListeners();
  }
  
  void clearError() {
    _errorMessage = null;
    notifyListeners();
  }
}
