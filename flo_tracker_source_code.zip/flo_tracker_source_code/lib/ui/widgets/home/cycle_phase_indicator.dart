import 'package:flutter/material.dart';
import 'package:flo_tracker/config/theme.dart';
import 'package:flo_tracker/viewmodels/cycle_viewmodel.dart';
import 'package:flo_tracker/viewmodels/fertility_viewmodel.dart';

class CyclePhaseIndicator extends StatelessWidget {
  final bool isTodayPeriodDay;
  final bool isTodayFertileDay;
  final bool isTodayOvulationDay;
  final int daysUntilNextPeriod;

  const CyclePhaseIndicator({
    Key? key,
    required this.isTodayPeriodDay,
    required this.isTodayFertileDay,
    required this.isTodayOvulationDay,
    required this.daysUntilNextPeriod,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: _getGradientColors(),
        ),
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: _getPrimaryColor().withOpacity(0.3),
            blurRadius: 10,
            offset: const Offset(0, 5),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(
                _getPhaseIcon(),
                color: Colors.white,
                size: 28,
              ),
              const SizedBox(width: 12),
              Text(
                _getPhaseTitle(),
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Text(
            _getPhaseDescription(),
            style: const TextStyle(
              color: Colors.white,
              fontSize: 16,
            ),
          ),
          const SizedBox(height: 16),
          LinearProgressIndicator(
            value: _getProgressValue(),
            backgroundColor: Colors.white.withOpacity(0.3),
            valueColor: const AlwaysStoppedAnimation<Color>(Colors.white),
            borderRadius: BorderRadius.circular(10),
          ),
        ],
      ),
    );
  }

  List<Color> _getGradientColors() {
    if (isTodayPeriodDay) {
      return [
        AppTheme.primaryColor,
        AppTheme.primaryDarkColor,
      ];
    } else if (isTodayOvulationDay) {
      return [
        AppTheme.ovulationDayColor,
        AppTheme.ovulationDayColor.withGreen(180),
      ];
    } else if (isTodayFertileDay) {
      return [
        AppTheme.fertileDayColor,
        AppTheme.fertileDayColor.withBlue(180),
      ];
    } else {
      return [
        AppTheme.secondaryColor,
        AppTheme.secondaryDarkColor,
      ];
    }
  }

  Color _getPrimaryColor() {
    if (isTodayPeriodDay) {
      return AppTheme.primaryColor;
    } else if (isTodayOvulationDay) {
      return AppTheme.ovulationDayColor;
    } else if (isTodayFertileDay) {
      return AppTheme.fertileDayColor;
    } else {
      return AppTheme.secondaryColor;
    }
  }

  IconData _getPhaseIcon() {
    if (isTodayPeriodDay) {
      return Icons.water_drop;
    } else if (isTodayOvulationDay) {
      return Icons.egg_alt;
    } else if (isTodayFertileDay) {
      return Icons.spa;
    } else {
      return Icons.calendar_today;
    }
  }

  String _getPhaseTitle() {
    if (isTodayPeriodDay) {
      return 'Period Day';
    } else if (isTodayOvulationDay) {
      return 'Ovulation Day';
    } else if (isTodayFertileDay) {
      return 'Fertile Window';
    } else if (daysUntilNextPeriod <= 7) {
      return 'Pre-Period Phase';
    } else {
      return 'Follicular Phase';
    }
  }

  String _getPhaseDescription() {
    if (isTodayPeriodDay) {
      return 'You\'re on your period. Take care of yourself!';
    } else if (isTodayOvulationDay) {
      return 'Today is your ovulation day. Highest chance of conception.';
    } else if (isTodayFertileDay) {
      return 'You\'re in your fertile window. High chance of conception.';
    } else if (daysUntilNextPeriod <= 7) {
      return 'Your next period is expected in $daysUntilNextPeriod days.';
    } else {
      return 'Your next period is expected in $daysUntilNextPeriod days.';
    }
  }

  double _getProgressValue() {
    if (isTodayPeriodDay) {
      // Assuming average period is 5 days
      return 0.2;
    } else if (daysUntilNextPeriod <= 28 && daysUntilNextPeriod > 0) {
      // Assuming average cycle is 28 days
      return 1 - (daysUntilNextPeriod / 28);
    } else {
      return 0.0;
    }
  }
}
