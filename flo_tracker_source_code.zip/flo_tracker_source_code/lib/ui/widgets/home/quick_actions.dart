import 'package:flutter/material.dart';
import 'package:flo_tracker/config/theme.dart';

class QuickActions extends StatelessWidget {
  final VoidCallback onLogPeriodStart;
  final VoidCallback onLogPeriodEnd;
  final VoidCallback onLogSymptoms;

  const QuickActions({
    Key? key,
    required this.onLogPeriodStart,
    required this.onLogPeriodEnd,
    required this.onLogSymptoms,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Quick Actions',
          style: Theme.of(context).textTheme.titleLarge,
        ),
        const SizedBox(height: 16),
        Row(
          children: [
            Expanded(
              child: _buildActionButton(
                context,
                icon: Icons.water_drop,
                label: 'Log Period Start',
                color: AppTheme.primaryColor,
                onTap: onLogPeriodStart,
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: _buildActionButton(
                context,
                icon: Icons.check_circle_outline,
                label: 'Log Period End',
                color: AppTheme.secondaryColor,
                onTap: onLogPeriodEnd,
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: _buildActionButton(
                context,
                icon: Icons.add_circle_outline,
                label: 'Log Symptoms',
                color: AppTheme.accentTeal,
                onTap: onLogSymptoms,
              ),
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildActionButton(
    BuildContext context, {
    required IconData icon,
    required String label,
    required Color color,
    required VoidCallback onTap,
  }) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(12),
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 16),
        decoration: BoxDecoration(
          color: color.withOpacity(0.1),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: color.withOpacity(0.3)),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              icon,
              color: color,
              size: 28,
            ),
            const SizedBox(height: 8),
            Text(
              label,
              textAlign: TextAlign.center,
              style: TextStyle(
                color: color,
                fontWeight: FontWeight.w500,
                fontSize: 12,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
