import 'package:flutter/material.dart';
import 'package:flo_tracker/config/theme.dart';
import 'package:flo_tracker/viewmodels/cycle_viewmodel.dart';
import 'package:flo_tracker/viewmodels/fertility_viewmodel.dart';

class TodayInsights extends StatelessWidget {
  final CycleViewModel cycleViewModel;
  final FertilityViewModel fertilityViewModel;

  const TodayInsights({
    Key? key,
    required this.cycleViewModel,
    required this.fertilityViewModel,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Today\'s Insights',
          style: Theme.of(context).textTheme.titleLarge,
        ),
        const SizedBox(height: 16),
        _buildInsightCard(
          context,
          title: 'Cycle Day',
          content: _getCycleDayContent(),
          icon: Icons.calendar_today,
          color: AppTheme.primaryColor,
        ),
        const SizedBox(height: 12),
        _buildInsightCard(
          context,
          title: 'Fertility Status',
          content: _getFertilityContent(),
          icon: _getFertilityIcon(),
          color: _getFertilityColor(),
        ),
        const SizedBox(height: 12),
        _buildInsightCard(
          context,
          title: 'Recommended',
          content: 'Log your symptoms today to improve predictions',
          icon: Icons.lightbulb_outline,
          color: AppTheme.accentYellow,
        ),
      ],
    );
  }

  Widget _buildInsightCard(
    BuildContext context, {
    required String title,
    required String content,
    required IconData icon,
    required Color color,
  }) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Theme.of(context).cardTheme.color,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 10,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            width: 48,
            height: 48,
            decoration: BoxDecoration(
              color: color.withOpacity(0.1),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Icon(
              icon,
              color: color,
              size: 24,
            ),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: Theme.of(context).textTheme.titleMedium?.copyWith(
                        fontWeight: FontWeight.w600,
                      ),
                ),
                const SizedBox(height: 4),
                Text(
                  content,
                  style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                        color: AppTheme.textSecondary,
                      ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  String _getCycleDayContent() {
    if (cycleViewModel.currentCycle == null) {
      return 'No cycle data available';
    }

    if (cycleViewModel.isTodayPeriodDay) {
      return 'You\'re on your period. Day ${_calculateCycleDay()} of your cycle.';
    } else {
      return 'Day ${_calculateCycleDay()} of your cycle. ${cycleViewModel.daysUntilNextPeriod} days until next period.';
    }
  }

  int _calculateCycleDay() {
    if (cycleViewModel.currentCycle == null) {
      return 0;
    }

    final today = DateTime.now();
    final cycleStart = cycleViewModel.currentCycle!.startDate;
    return today.difference(cycleStart).inDays + 1;
  }

  String _getFertilityContent() {
    if (fertilityViewModel.isTodayOvulationDay) {
      return 'Today is your ovulation day. Highest chance of conception.';
    } else if (fertilityViewModel.isTodayFertileDay) {
      return 'You\'re in your fertile window. High chance of conception.';
    } else if (cycleViewModel.isTodayPeriodDay) {
      return 'You\'re on your period. Low fertility.';
    } else {
      return 'Low fertility today.';
    }
  }

  IconData _getFertilityIcon() {
    if (fertilityViewModel.isTodayOvulationDay) {
      return Icons.egg_alt;
    } else if (fertilityViewModel.isTodayFertileDay) {
      return Icons.spa;
    } else {
      return Icons.water_drop;
    }
  }

  Color _getFertilityColor() {
    if (fertilityViewModel.isTodayOvulationDay) {
      return AppTheme.ovulationDayColor;
    } else if (fertilityViewModel.isTodayFertileDay) {
      return AppTheme.fertileDayColor;
    } else {
      return AppTheme.secondaryColor;
    }
  }
}
