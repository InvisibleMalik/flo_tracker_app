import 'package:flutter/material.dart';
import 'package:flo_tracker/config/theme.dart';
import 'package:flo_tracker/viewmodels/cycle_viewmodel.dart';
import 'package:flo_tracker/viewmodels/fertility_viewmodel.dart';
import 'package:table_calendar/table_calendar.dart';

class MonthCalendar extends StatefulWidget {
  final CycleViewModel cycleViewModel;
  final FertilityViewModel fertilityViewModel;
  final Function(DateTime) onDaySelected;

  const MonthCalendar({
    Key? key,
    required this.cycleViewModel,
    required this.fertilityViewModel,
    required this.onDaySelected,
  }) : super(key: key);

  @override
  State<MonthCalendar> createState() => _MonthCalendarState();
}

class _MonthCalendarState extends State<MonthCalendar> {
  CalendarFormat _calendarFormat = CalendarFormat.month;
  DateTime _focusedDay = DateTime.now();
  DateTime? _selectedDay;

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: Theme.of(context).cardTheme.color,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 10,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: TableCalendar(
        firstDay: DateTime.utc(2020, 1, 1),
        lastDay: DateTime.utc(2030, 12, 31),
        focusedDay: _focusedDay,
        calendarFormat: _calendarFormat,
        selectedDayPredicate: (day) {
          return isSameDay(_selectedDay, day);
        },
        onDaySelected: (selectedDay, focusedDay) {
          setState(() {
            _selectedDay = selectedDay;
            _focusedDay = focusedDay;
          });
          widget.onDaySelected(selectedDay);
        },
        onFormatChanged: (format) {
          setState(() {
            _calendarFormat = format;
          });
        },
        onPageChanged: (focusedDay) {
          _focusedDay = focusedDay;
        },
        calendarStyle: CalendarStyle(
          outsideDaysVisible: false,
          markersMaxCount: 3,
          markersAnchor: 0.7,
          markerDecoration: const BoxDecoration(
            color: AppTheme.primaryColor,
            shape: BoxShape.circle,
          ),
        ),
        headerStyle: HeaderStyle(
          titleCentered: true,
          formatButtonVisible: false,
          titleTextStyle: Theme.of(context).textTheme.titleLarge!,
        ),
        calendarBuilders: CalendarBuilders(
          defaultBuilder: (context, day, focusedDay) {
            return _buildCalendarDay(day);
          },
          selectedBuilder: (context, day, focusedDay) {
            return Container(
              margin: const EdgeInsets.all(4.0),
              decoration: BoxDecoration(
                color: AppTheme.primaryLightColor,
                shape: BoxShape.circle,
                border: Border.all(
                  color: AppTheme.primaryColor,
                  width: 2,
                ),
              ),
              child: Center(
                child: Text(
                  '${day.day}',
                  style: const TextStyle(
                    color: AppTheme.primaryDarkColor,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            );
          },
          todayBuilder: (context, day, focusedDay) {
            return Container(
              margin: const EdgeInsets.all(4.0),
              decoration: BoxDecoration(
                color: Colors.transparent,
                shape: BoxShape.circle,
                border: Border.all(
                  color: AppTheme.primaryColor,
                  width: 2,
                ),
              ),
              child: Center(
                child: Text(
                  '${day.day}',
                  style: const TextStyle(
                    color: AppTheme.primaryColor,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            );
          },
        ),
      ),
    );
  }

  Widget _buildCalendarDay(DateTime day) {
    // Check if day is a period day
    bool isPeriodDay = _isPeriodDay(day);
    bool isPredictedPeriodDay = _isPredictedPeriodDay(day);
    bool isFertileDay = _isFertileDay(day);
    bool isOvulationDay = _isOvulationDay(day);

    Color backgroundColor = Colors.transparent;
    Color textColor = Theme.of(context).textTheme.bodyMedium!.color!;

    if (isPeriodDay) {
      backgroundColor = AppTheme.periodDayColor;
      textColor = Colors.white;
    } else if (isPredictedPeriodDay) {
      backgroundColor = AppTheme.predictedPeriodColor;
      textColor = AppTheme.primaryDarkColor;
    } else if (isOvulationDay) {
      backgroundColor = AppTheme.ovulationDayColor;
      textColor = Colors.white;
    } else if (isFertileDay) {
      backgroundColor = AppTheme.fertileDayColor;
      textColor = Colors.white;
    }

    return Container(
      margin: const EdgeInsets.all(4.0),
      decoration: BoxDecoration(
        color: backgroundColor,
        shape: BoxShape.circle,
      ),
      child: Center(
        child: Text(
          '${day.day}',
          style: TextStyle(
            color: textColor,
          ),
        ),
      ),
    );
  }

  bool _isPeriodDay(DateTime day) {
    for (var cycle in widget.cycleViewModel.cycles) {
      if (cycle.startDate.year == day.year &&
          cycle.startDate.month == day.month &&
          cycle.startDate.day == day.day) {
        return true;
      }

      if (cycle.endDate != null) {
        // Check if day is between start and end date
        if (day.isAfter(cycle.startDate) && day.isBefore(cycle.endDate!)) {
          return true;
        }

        // Check if day is the end date
        if (cycle.endDate!.year == day.year &&
            cycle.endDate!.month == day.month &&
            cycle.endDate!.day == day.day) {
          return true;
        }
      } else {
        // If no end date, assume period is ongoing if started within last 5 days
        final difference = DateTime.now().difference(cycle.startDate).inDays;
        if (difference <= 5 &&
            day.isAfter(cycle.startDate) &&
            day.isBefore(DateTime.now())) {
          return true;
        }
      }
    }
    return false;
  }

  bool _isPredictedPeriodDay(DateTime day) {
    for (var cycle in widget.cycleViewModel.predictions) {
      if (cycle.startDate.year == day.year &&
          cycle.startDate.month == day.month &&
          cycle.startDate.day == day.day) {
        return true;
      }

      if (cycle.endDate != null) {
        // Check if day is between start and end date
        if (day.isAfter(cycle.startDate) && day.isBefore(cycle.endDate!)) {
          return true;
        }

        // Check if day is the end date
        if (cycle.endDate!.year == day.year &&
            cycle.endDate!.month == day.month &&
            cycle.endDate!.day == day.day) {
          return true;
        }
      }
    }
    return false;
  }

  bool _isFertileDay(DateTime day) {
    final normalizedDay = DateTime(day.year, day.month, day.day);
    
    // Check actual fertility data
    final fertilityData = widget.fertilityViewModel.getFertilityDataForDate(normalizedDay);
    if (fertilityData != null) {
      return fertilityData.isFertileDay && !fertilityData.isOvulationDay;
    }
    
    // Check fertility predictions
    for (var prediction in widget.fertilityViewModel.fertilityPredictions) {
      if (prediction.date.year == day.year &&
          prediction.date.month == day.month &&
          prediction.date.day == day.day) {
        return prediction.isFertileDay && !prediction.isOvulationDay;
      }
    }
    
    return false;
  }

  bool _isOvulationDay(DateTime day) {
    final normalizedDay = DateTime(day.year, day.month, day.day);
    
    // Check actual fertility data
    final fertilityData = widget.fertilityViewModel.getFertilityDataForDate(normalizedDay);
    if (fertilityData != null) {
      return fertilityData.isOvulationDay;
    }
    
    // Check fertility predictions
    for (var prediction in widget.fertilityViewModel.fertilityPredictions) {
      if (prediction.date.year == day.year &&
          prediction.date.month == day.month &&
          prediction.date.day == day.day) {
        return prediction.isOvulationDay;
      }
    }
    
    return false;
  }
}
