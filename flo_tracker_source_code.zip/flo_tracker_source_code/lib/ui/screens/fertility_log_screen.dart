import 'package:flutter/material.dart';
import 'package:flo_tracker/config/theme.dart';
import 'package:flo_tracker/viewmodels/fertility_viewmodel.dart';
import 'package:provider/provider.dart';

class FertilityLogScreen extends StatefulWidget {
  final DateTime? date;

  const FertilityLogScreen({Key? key, this.date}) : super(key: key);

  @override
  State<FertilityLogScreen> createState() => _FertilityLogScreenState();
}

class _FertilityLogScreenState extends State<FertilityLogScreen> {
  late DateTime _selectedDate;
  double? _basalBodyTemperature;
  String? _cervicalMucusType;
  String? _ovulationTestResult;
  final TextEditingController _temperatureController = TextEditingController();

  final List<String> _mucusTypes = [
    'Dry',
    'Sticky',
    'Creamy',
    'Watery',
    'Egg-white',
  ];

  final List<String> _testResults = [
    'Negative',
    'Positive',
    'Invalid',
  ];

  @override
  void initState() {
    super.initState();
    _selectedDate = widget.date ?? DateTime.now();
  }

  @override
  void dispose() {
    _temperatureController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Log Fertility Data'),
        centerTitle: true,
        elevation: 0,
      ),
      body: Consumer<FertilityViewModel>(
        builder: (context, fertilityViewModel, _) {
          if (fertilityViewModel.isLoading) {
            return const Center(child: CircularProgressIndicator());
          }

          // Check if we already have data for this date
          final existingData = fertilityViewModel.getFertilityDataForDate(_selectedDate);
          if (existingData != null && _basalBodyTemperature == null) {
            // Initialize form with existing data
            _basalBodyTemperature = existingData.basalBodyTemperature;
            _cervicalMucusType = existingData.cervicalMucusType;
            _ovulationTestResult = existingData.ovulationTestResult;
            
            if (_basalBodyTemperature != null) {
              _temperatureController.text = _basalBodyTemperature!.toString();
            }
          }

          return SingleChildScrollView(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _buildDateSelector(),
                const SizedBox(height: 24),
                Text(
                  'Basal Body Temperature',
                  style: Theme.of(context).textTheme.titleLarge,
                ),
                const SizedBox(height: 8),
                Text(
                  'Take your temperature first thing in the morning, before getting out of bed.',
                  style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                        color: AppTheme.textSecondary,
                      ),
                ),
                const SizedBox(height: 16),
                TextField(
                  controller: _temperatureController,
                  decoration: const InputDecoration(
                    labelText: 'Temperature (°C)',
                    hintText: 'e.g., 36.7',
                    border: OutlineInputBorder(),
                    suffixText: '°C',
                  ),
                  keyboardType: const TextInputType.numberWithOptions(decimal: true),
                  onChanged: (value) {
                    if (value.isNotEmpty) {
                      setState(() {
                        _basalBodyTemperature = double.tryParse(value);
                      });
                    } else {
                      setState(() {
                        _basalBodyTemperature = null;
                      });
                    }
                  },
                ),
                const SizedBox(height: 24),
                Text(
                  'Cervical Mucus',
                  style: Theme.of(context).textTheme.titleLarge,
                ),
                const SizedBox(height: 8),
                Text(
                  'Select the type that best describes your cervical mucus today.',
                  style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                        color: AppTheme.textSecondary,
                      ),
                ),
                const SizedBox(height: 16),
                _buildMucusTypeSelector(),
                const SizedBox(height: 24),
                Text(
                  'Ovulation Test',
                  style: Theme.of(context).textTheme.titleLarge,
                ),
                const SizedBox(height: 8),
                Text(
                  'If you used an ovulation test today, record the result.',
                  style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                        color: AppTheme.textSecondary,
                      ),
                ),
                const SizedBox(height: 16),
                _buildTestResultSelector(),
                const SizedBox(height: 32),
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    onPressed: () => _logFertilityData(fertilityViewModel),
                    child: const Text('Save'),
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }

  Widget _buildDateSelector() {
    return InkWell(
      onTap: () async {
        final DateTime? picked = await showDatePicker(
          context: context,
          initialDate: _selectedDate,
          firstDate: DateTime.now().subtract(const Duration(days: 90)),
          lastDate: DateTime.now(),
        );
        if (picked != null) {
          setState(() {
            _selectedDate = picked;
          });
        }
      },
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: Theme.of(context).cardTheme.color,
          borderRadius: BorderRadius.circular(12),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.05),
              blurRadius: 10,
              offset: const Offset(0, 2),
            ),
          ],
        ),
        child: Row(
          children: [
            Icon(
              Icons.calendar_today,
              color: AppTheme.fertileDayColor,
            ),
            const SizedBox(width: 16),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Date',
                  style: Theme.of(context).textTheme.titleMedium,
                ),
                Text(
                  _formatDate(_selectedDate),
                  style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                        color: AppTheme.textSecondary,
                      ),
                ),
              ],
            ),
            const Spacer(),
            Icon(
              Icons.arrow_drop_down,
              color: AppTheme.textSecondary,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildMucusTypeSelector() {
    return Wrap(
      spacing: 8,
      runSpacing: 8,
      children: _mucusTypes.map((type) {
        final isSelected = _cervicalMucusType == type.toLowerCase();
        return ChoiceChip(
          label: Text(type),
          selected: isSelected,
          onSelected: (selected) {
            setState(() {
              _cervicalMucusType = selected ? type.toLowerCase() : null;
            });
          },
          backgroundColor: Theme.of(context).cardTheme.color,
          selectedColor: AppTheme.fertileDayColor,
          labelStyle: TextStyle(
            color: isSelected ? Colors.white : AppTheme.textPrimary,
          ),
        );
      }).toList(),
    );
  }

  Widget _buildTestResultSelector() {
    return Wrap(
      spacing: 8,
      runSpacing: 8,
      children: _testResults.map((result) {
        final isSelected = _ovulationTestResult == result.toLowerCase();
        Color chipColor;
        
        if (result == 'Positive') {
          chipColor = AppTheme.ovulationDayColor;
        } else if (result == 'Negative') {
          chipColor = AppTheme.secondaryColor;
        } else {
          chipColor = AppTheme.warning;
        }
        
        return ChoiceChip(
          label: Text(result),
          selected: isSelected,
          onSelected: (selected) {
            setState(() {
              _ovulationTestResult = selected ? result.toLowerCase() : null;
            });
          },
          backgroundColor: Theme.of(context).cardTheme.color,
          selectedColor: chipColor,
          labelStyle: TextStyle(
            color: isSelected ? Colors.white : AppTheme.textPrimary,
          ),
        );
      }).toList(),
    );
  }

  void _logFertilityData(FertilityViewModel fertilityViewModel) async {
    // Validate temperature if provided
    if (_temperatureController.text.isNotEmpty) {
      final temp = double.tryParse(_temperatureController.text);
      if (temp == null || temp < 35.0 || temp > 39.0) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Please enter a valid temperature between 35.0 and 39.0°C'),
            backgroundColor: AppTheme.error,
          ),
        );
        return;
      }
    }

    final success = await fertilityViewModel.logFertilityData(
      _selectedDate,
      basalBodyTemperature: _basalBodyTemperature,
      cervicalMucusType: _cervicalMucusType,
      ovulationTestResult: _ovulationTestResult,
    );

    if (success && mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Fertility data logged successfully'),
          backgroundColor: AppTheme.success,
        ),
      );
      Navigator.of(context).pop();
    } else if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(fertilityViewModel.errorMessage ?? 'Failed to log fertility data'),
          backgroundColor: AppTheme.error,
        ),
      );
    }
  }

  String _formatDate(DateTime date) {
    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);
    final yesterday = today.subtract(const Duration(days: 1));
    
    if (date.year == today.year && date.month == today.month && date.day == today.day) {
      return 'Today';
    } else if (date.year == yesterday.year && date.month == yesterday.month && date.day == yesterday.day) {
      return 'Yesterday';
    } else {
      return '${date.day}/${date.month}/${date.year}';
    }
  }
}
