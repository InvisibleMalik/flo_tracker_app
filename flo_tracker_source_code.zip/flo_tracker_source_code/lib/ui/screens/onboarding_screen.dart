import 'package:flutter/material.dart';
import 'package:flo_tracker/config/theme.dart';
import 'package:flo_tracker/config/routes.dart';
import 'package:provider/provider.dart';
import 'package:flo_tracker/viewmodels/auth_viewmodel.dart';
import 'package:flo_tracker/viewmodels/cycle_viewmodel.dart';

class OnboardingScreen extends StatefulWidget {
  const OnboardingScreen({Key? key}) : super(key: key);

  @override
  State<OnboardingScreen> createState() => _OnboardingScreenState();
}

class _OnboardingScreenState extends State<OnboardingScreen> {
  final PageController _pageController = PageController();
  int _currentPage = 0;
  final int _totalPages = 3;
  
  // Basic information
  DateTime? _lastPeriodDate;
  int _cycleLength = 28;
  
  // Tracking goals
  bool _trackPeriod = true;
  bool _trackFertility = false;
  bool _tryingToConceive = false;
  bool _trackPregnancy = false;
  
  // Notification preferences
  bool _periodReminders = true;
  bool _fertilityAlerts = false;
  bool _dailyLoggingReminders = true;

  @override
  void dispose() {
    _pageController.dispose();
    super.dispose();
  }

  void _nextPage() {
    if (_currentPage < _totalPages - 1) {
      _pageController.nextPage(
        duration: const Duration(milliseconds: 300),
        curve: Curves.easeInOut,
      );
    } else {
      _completeOnboarding();
    }
  }

  void _previousPage() {
    if (_currentPage > 0) {
      _pageController.previousPage(
        duration: const Duration(milliseconds: 300),
        curve: Curves.easeInOut,
      );
    }
  }

  void _completeOnboarding() async {
    // Initialize cycle tracking with the provided information
    final cycleViewModel = Provider.of<CycleViewModel>(context, listen: false);
    
    // In a real app, we would save these preferences to the backend
    // For now, we'll just navigate to the home screen
    Navigator.of(context).pushReplacementNamed(Routes.home);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 24.0, vertical: 16.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  _currentPage > 0
                      ? IconButton(
                          icon: const Icon(Icons.arrow_back),
                          onPressed: _previousPage,
                        )
                      : const SizedBox(width: 48),
                  Text(
                    'Step ${_currentPage + 1} of $_totalPages',
                    style: Theme.of(context).textTheme.bodyMedium,
                  ),
                  TextButton(
                    onPressed: () {
                      Navigator.of(context).pushReplacementNamed(Routes.home);
                    },
                    child: const Text('Skip'),
                  ),
                ],
              ),
            ),
            LinearProgressIndicator(
              value: (_currentPage + 1) / _totalPages,
              backgroundColor: AppTheme.divider,
              valueColor: AlwaysStoppedAnimation<Color>(AppTheme.primaryColor),
            ),
            Expanded(
              child: PageView(
                controller: _pageController,
                onPageChanged: (int page) {
                  setState(() {
                    _currentPage = page;
                  });
                },
                children: [
                  _buildBasicInfoPage(),
                  _buildTrackingGoalsPage(),
                  _buildNotificationPreferencesPage(),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(24.0),
              child: ElevatedButton(
                onPressed: _nextPage,
                child: Text(_currentPage < _totalPages - 1 ? 'Continue' : 'Get Started'),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildBasicInfoPage() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(24.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Basic Information',
            style: Theme.of(context).textTheme.headlineMedium,
          ),
          const SizedBox(height: 8),
          Text(
            'Let\'s personalize your experience',
            style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                  color: AppTheme.textSecondary,
                ),
          ),
          const SizedBox(height: 32),
          Text(
            'When did your last period start?',
            style: Theme.of(context).textTheme.titleLarge,
          ),
          const SizedBox(height: 16),
          InkWell(
            onTap: () async {
              final DateTime? picked = await showDatePicker(
                context: context,
                initialDate: _lastPeriodDate ?? DateTime.now(),
                firstDate: DateTime.now().subtract(const Duration(days: 90)),
                lastDate: DateTime.now(),
              );
              if (picked != null) {
                setState(() {
                  _lastPeriodDate = picked;
                });
              }
            },
            child: Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                border: Border.all(color: AppTheme.divider),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    _lastPeriodDate == null
                        ? 'Select date'
                        : '${_lastPeriodDate!.day}/${_lastPeriodDate!.month}/${_lastPeriodDate!.year}',
                    style: Theme.of(context).textTheme.bodyLarge,
                  ),
                  const Icon(Icons.calendar_today),
                ],
              ),
            ),
          ),
          const SizedBox(height: 32),
          Text(
            'What is your average cycle length?',
            style: Theme.of(context).textTheme.titleLarge,
          ),
          const SizedBox(height: 8),
          Text(
            'The average cycle is 28 days, counting from the first day of your period to the day before your next period starts.',
            style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                  color: AppTheme.textSecondary,
                ),
          ),
          const SizedBox(height: 16),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              IconButton(
                icon: const Icon(Icons.remove_circle_outline),
                onPressed: () {
                  if (_cycleLength > 21) {
                    setState(() {
                      _cycleLength--;
                    });
                  }
                },
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
                decoration: BoxDecoration(
                  border: Border.all(color: AppTheme.divider),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Text(
                  '$_cycleLength days',
                  style: Theme.of(context).textTheme.headlineSmall,
                ),
              ),
              IconButton(
                icon: const Icon(Icons.add_circle_outline),
                onPressed: () {
                  if (_cycleLength < 35) {
                    setState(() {
                      _cycleLength++;
                    });
                  }
                },
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildTrackingGoalsPage() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(24.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Tracking Goals',
            style: Theme.of(context).textTheme.headlineMedium,
          ),
          const SizedBox(height: 8),
          Text(
            'What would you like to track?',
            style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                  color: AppTheme.textSecondary,
                ),
          ),
          const SizedBox(height: 32),
          _buildTrackingOption(
            title: 'Period Tracking',
            description: 'Track your period and predict your next one',
            icon: Icons.calendar_today,
            isSelected: _trackPeriod,
            onChanged: (value) {
              setState(() {
                _trackPeriod = value ?? true;
              });
            },
          ),
          const SizedBox(height: 16),
          _buildTrackingOption(
            title: 'Fertility Tracking',
            description: 'Monitor your fertile window and ovulation',
            icon: Icons.spa,
            isSelected: _trackFertility,
            onChanged: (value) {
              setState(() {
                _trackFertility = value ?? false;
              });
            },
          ),
          const SizedBox(height: 16),
          _buildTrackingOption(
            title: 'Trying to Conceive',
            description: 'Get insights to help you conceive',
            icon: Icons.child_friendly,
            isSelected: _tryingToConceive,
            onChanged: (value) {
              setState(() {
                _tryingToConceive = value ?? false;
                if (_tryingToConceive) {
                  _trackFertility = true;
                }
              });
            },
          ),
          const SizedBox(height: 16),
          _buildTrackingOption(
            title: 'Pregnancy Tracking',
            description: 'Track your pregnancy journey',
            icon: Icons.pregnant_woman,
            isSelected: _trackPregnancy,
            onChanged: (value) {
              setState(() {
                _trackPregnancy = value ?? false;
              });
            },
          ),
        ],
      ),
    );
  }

  Widget _buildNotificationPreferencesPage() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(24.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Notification Preferences',
            style: Theme.of(context).textTheme.headlineMedium,
          ),
          const SizedBox(height: 8),
          Text(
            'How would you like to be reminded?',
            style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                  color: AppTheme.textSecondary,
                ),
          ),
          const SizedBox(height: 32),
          _buildNotificationOption(
            title: 'Period Reminders',
            description: 'Get notified before your period starts',
            isEnabled: _periodReminders,
            onChanged: (value) {
              setState(() {
                _periodReminders = value ?? true;
              });
            },
          ),
          const SizedBox(height: 16),
          _buildNotificationOption(
            title: 'Fertility Window Alerts',
            description: 'Get notified during your fertile days',
            isEnabled: _fertilityAlerts,
            onChanged: (value) {
              setState(() {
                _fertilityAlerts = value ?? false;
              });
            },
          ),
          const SizedBox(height: 16),
          _buildNotificationOption(
            title: 'Daily Logging Reminders',
            description: 'Get reminded to log your symptoms daily',
            isEnabled: _dailyLoggingReminders,
            onChanged: (value) {
              setState(() {
                _dailyLoggingReminders = value ?? true;
              });
            },
          ),
          const SizedBox(height: 32),
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: AppTheme.info.withOpacity(0.1),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Row(
              children: [
                Icon(
                  Icons.info_outline,
                  color: AppTheme.info,
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: Text(
                    'You can change these preferences anytime in the app settings.',
                    style: TextStyle(color: AppTheme.info),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTrackingOption({
    required String title,
    required String description,
    required IconData icon,
    required bool isSelected,
    required ValueChanged<bool?> onChanged,
  }) {
    return Container(
      decoration: BoxDecoration(
        border: Border.all(
          color: isSelected ? AppTheme.primaryColor : AppTheme.divider,
        ),
        borderRadius: BorderRadius.circular(12),
        color: isSelected ? AppTheme.primaryLightColor : null,
      ),
      child: CheckboxListTile(
        title: Text(
          title,
          style: Theme.of(context).textTheme.titleLarge,
        ),
        subtitle: Text(
          description,
          style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                color: AppTheme.textSecondary,
              ),
        ),
        secondary: Icon(
          icon,
          color: isSelected ? AppTheme.primaryColor : AppTheme.textSecondary,
          size: 32,
        ),
        value: isSelected,
        onChanged: onChanged,
        activeColor: AppTheme.primaryColor,
        checkColor: Colors.white,
        contentPadding: const EdgeInsets.all(16),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
        ),
      ),
    );
  }

  Widget _buildNotificationOption({
    required String title,
    required String description,
    required bool isEnabled,
    required ValueChanged<bool?> onChanged,
  }) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        border: Border.all(color: AppTheme.divider),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: Theme.of(context).textTheme.titleLarge,
                ),
                const SizedBox(height: 4),
                Text(
                  description,
                  style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                        color: AppTheme.textSecondary,
                      ),
                ),
              ],
            ),
          ),
          Switch(
            value: isEnabled,
            onChanged: onChanged,
            activeColor: AppTheme.primaryColor,
          ),
        ],
      ),
    );
  }
}
