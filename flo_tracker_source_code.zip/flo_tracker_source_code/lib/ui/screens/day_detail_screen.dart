import 'package:flutter/material.dart';
import 'package:flo_tracker/config/theme.dart';
import 'package:flo_tracker/viewmodels/symptom_viewmodel.dart';

class DayDetailScreen extends StatefulWidget {
  final DateTime date;

  const DayDetailScreen({Key? key, required this.date}) : super(key: key);

  @override
  State<DayDetailScreen> createState() => _DayDetailScreenState();
}

class _DayDetailScreenState extends State<DayDetailScreen> with SingleTickerProviderStateMixin {
  late TabController _tabController;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          _formatDate(widget.date),
          style: const TextStyle(
            fontWeight: FontWeight.w600,
          ),
        ),
        centerTitle: true,
        elevation: 0,
        actions: [
          IconButton(
            icon: const Icon(Icons.edit_note),
            onPressed: () {
              // TODO: Navigate to edit notes
            },
          ),
        ],
      ),
      body: Column(
        children: [
          Container(
            color: Theme.of(context).scaffoldBackgroundColor,
            child: TabBar(
              controller: _tabController,
              labelColor: AppTheme.primaryColor,
              unselectedLabelColor: AppTheme.textDisabled,
              indicatorColor: AppTheme.primaryColor,
              tabs: const [
                Tab(text: 'Symptoms'),
                Tab(text: 'Fertility'),
                Tab(text: 'Notes'),
              ],
            ),
          ),
          Expanded(
            child: TabBarView(
              controller: _tabController,
              children: [
                _buildSymptomsTab(),
                _buildFertilityTab(),
                _buildNotesTab(),
              ],
            ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          if (_tabController.index == 0) {
            Navigator.of(context).pushNamed('/symptom-log', arguments: {'date': widget.date});
          } else if (_tabController.index == 1) {
            Navigator.of(context).pushNamed('/fertility-log', arguments: {'date': widget.date});
          } else {
            // TODO: Show note editor
          }
        },
        backgroundColor: AppTheme.primaryColor,
        child: const Icon(Icons.add),
      ),
    );
  }

  Widget _buildSymptomsTab() {
    return Consumer<SymptomViewModel>(
      builder: (context, symptomViewModel, _) {
        final symptoms = symptomViewModel.getSymptomsForDate(widget.date);
        
        if (symptoms.isEmpty) {
          return Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(
                  Icons.sentiment_neutral,
                  size: 64,
                  color: AppTheme.textDisabled,
                ),
                const SizedBox(height: 16),
                Text(
                  'No symptoms logged for this day',
                  style: TextStyle(
                    color: AppTheme.textSecondary,
                    fontSize: 16,
                  ),
                ),
                const SizedBox(height: 8),
                ElevatedButton.icon(
                  onPressed: () {
                    Navigator.of(context).pushNamed('/symptom-log', arguments: {'date': widget.date});
                  },
                  icon: const Icon(Icons.add),
                  label: const Text('Log Symptoms'),
                ),
              ],
            ),
          );
        }
        
        // Group symptoms by category
        final Map<String, List<UserSymptom>> symptomsByCategory = {};
        for (final symptom in symptoms) {
          if (!symptomsByCategory.containsKey(symptom.category)) {
            symptomsByCategory[symptom.category] = [];
          }
          symptomsByCategory[symptom.category]!.add(symptom);
        }
        
        return ListView.builder(
          padding: const EdgeInsets.all(16),
          itemCount: symptomsByCategory.length,
          itemBuilder: (context, index) {
            final category = symptomsByCategory.keys.elementAt(index);
            final categorySymptoms = symptomsByCategory[category]!;
            
            return Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  category,
                  style: Theme.of(context).textTheme.titleLarge,
                ),
                const SizedBox(height: 8),
                ...categorySymptoms.map((symptom) => _buildSymptomItem(symptom)),
                const SizedBox(height: 16),
              ],
            );
          },
        );
      },
    );
  }

  Widget _buildSymptomItem(UserSymptom symptom) {
    return Card(
      margin: const EdgeInsets.only(bottom: 8),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Row(
          children: [
            Container(
              width: 48,
              height: 48,
              decoration: BoxDecoration(
                color: _getCategoryColor(symptom.category).withOpacity(0.1),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Center(
                child: Text(
                  symptom.symptomName.substring(0, 1),
                  style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                    color: _getCategoryColor(symptom.category),
                  ),
                ),
              ),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    symptom.symptomName,
                    style: Theme.of(context).textTheme.titleMedium,
                  ),
                  if (symptom.intensity != null)
                    Row(
                      children: [
                        Text(
                          'Intensity: ',
                          style: Theme.of(context).textTheme.bodySmall,
                        ),
                        _buildIntensityIndicator(symptom.intensity!),
                      ],
                    ),
                  if (symptom.notes != null && symptom.notes!.isNotEmpty)
                    Text(
                      symptom.notes!,
                      style: Theme.of(context).textTheme.bodySmall,
                    ),
                ],
              ),
            ),
            IconButton(
              icon: const Icon(Icons.delete_outline),
              onPressed: () {
                // TODO: Delete symptom
              },
              color: AppTheme.error,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildIntensityIndicator(int intensity) {
    return Row(
      children: List.generate(5, (index) {
        return Icon(
          index < intensity ? Icons.circle : Icons.circle_outlined,
          size: 12,
          color: index < intensity ? AppTheme.primaryColor : AppTheme.textDisabled,
        );
      }),
    );
  }

  Color _getCategoryColor(String category) {
    switch (category) {
      case 'Mood':
        return AppTheme.secondaryColor;
      case 'Pain':
        return AppTheme.error;
      case 'Discharge':
        return AppTheme.primaryColor;
      case 'Body':
        return AppTheme.accentTeal;
      default:
        return AppTheme.primaryColor;
    }
  }

  Widget _buildFertilityTab() {
    // Placeholder for fertility tab
    return Center(
      child: Text(
        'Fertility data for ${_formatDate(widget.date)} will be shown here',
        style: TextStyle(
          color: AppTheme.textSecondary,
        ),
      ),
    );
  }

  Widget _buildNotesTab() {
    // Placeholder for notes tab
    return Center(
      child: Text(
        'Notes for ${_formatDate(widget.date)} will be shown here',
        style: TextStyle(
          color: AppTheme.textSecondary,
        ),
      ),
    );
  }

  String _formatDate(DateTime date) {
    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);
    final yesterday = today.subtract(const Duration(days: 1));
    final tomorrow = today.add(const Duration(days: 1));
    
    if (date.year == today.year && date.month == today.month && date.day == today.day) {
      return 'Today';
    } else if (date.year == yesterday.year && date.month == yesterday.month && date.day == yesterday.day) {
      return 'Yesterday';
    } else if (date.year == tomorrow.year && date.month == tomorrow.month && date.day == tomorrow.day) {
      return 'Tomorrow';
    } else {
      return '${date.day}/${date.month}/${date.year}';
    }
  }
}
