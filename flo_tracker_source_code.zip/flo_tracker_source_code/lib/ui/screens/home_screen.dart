import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:flo_tracker/config/theme.dart';
import 'package:flo_tracker/config/routes.dart';
import 'package:flo_tracker/viewmodels/auth_viewmodel.dart';
import 'package:flo_tracker/viewmodels/cycle_viewmodel.dart';
import 'package:flo_tracker/viewmodels/symptom_viewmodel.dart';
import 'package:flo_tracker/viewmodels/fertility_viewmodel.dart';
import 'package:flo_tracker/ui/widgets/common/custom_app_bar.dart';
import 'package:flo_tracker/ui/widgets/common/custom_bottom_navigation.dart';
import 'package:flo_tracker/ui/widgets/home/cycle_phase_indicator.dart';
import 'package:flo_tracker/ui/widgets/home/quick_actions.dart';
import 'package:flo_tracker/ui/widgets/home/today_insights.dart';
import 'package:flo_tracker/ui/widgets/calendar/month_calendar.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({Key? key}) : super(key: key);

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _selectedIndex = 0;
  final PageController _pageController = PageController();

  @override
  void initState() {
    super.initState();
    _initializeData();
  }

  Future<void> _initializeData() async {
    // Initialize all view models
    final cycleViewModel = Provider.of<CycleViewModel>(context, listen: false);
    final symptomViewModel = Provider.of<SymptomViewModel>(context, listen: false);
    final fertilityViewModel = Provider.of<FertilityViewModel>(context, listen: false);

    await cycleViewModel.initialize();
    await symptomViewModel.initialize();
    await fertilityViewModel.initialize();
  }

  @override
  void dispose() {
    _pageController.dispose();
    super.dispose();
  }

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
      _pageController.jumpToPage(index);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: CustomAppBar(
        title: _getAppBarTitle(),
        actions: [
          IconButton(
            icon: const Icon(Icons.notifications_outlined),
            onPressed: () {
              // TODO: Navigate to notifications
            },
          ),
        ],
      ),
      body: PageView(
        controller: _pageController,
        physics: const NeverScrollableScrollPhysics(),
        children: [
          _buildHomeTab(),
          _buildInsightsTab(),
          _buildLogTab(),
          _buildArticlesTab(),
          _buildProfileTab(),
        ],
      ),
      bottomNavigationBar: CustomBottomNavigation(
        selectedIndex: _selectedIndex,
        onItemTapped: _onItemTapped,
      ),
    );
  }

  String _getAppBarTitle() {
    switch (_selectedIndex) {
      case 0:
        return 'Home';
      case 1:
        return 'Insights';
      case 2:
        return 'Log';
      case 3:
        return 'Articles';
      case 4:
        return 'Profile';
      default:
        return 'Flo Tracker';
    }
  }

  Widget _buildHomeTab() {
    return Consumer2<CycleViewModel, FertilityViewModel>(
      builder: (context, cycleViewModel, fertilityViewModel, _) {
        if (cycleViewModel.isLoading || fertilityViewModel.isLoading) {
          return const Center(child: CircularProgressIndicator());
        }

        return SingleChildScrollView(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              CyclePhaseIndicator(
                isTodayPeriodDay: cycleViewModel.isTodayPeriodDay,
                isTodayFertileDay: fertilityViewModel.isTodayFertileDay,
                isTodayOvulationDay: fertilityViewModel.isTodayOvulationDay,
                daysUntilNextPeriod: cycleViewModel.daysUntilNextPeriod,
              ),
              const SizedBox(height: 24),
              MonthCalendar(
                cycleViewModel: cycleViewModel,
                fertilityViewModel: fertilityViewModel,
                onDaySelected: (date) {
                  Navigator.of(context).pushNamed(
                    Routes.dayDetail,
                    arguments: DayDetailArguments(date: date),
                  );
                },
              ),
              const SizedBox(height: 24),
              QuickActions(
                onLogPeriodStart: () {
                  // TODO: Show period start dialog
                },
                onLogPeriodEnd: () {
                  // TODO: Show period end dialog
                },
                onLogSymptoms: () {
                  Navigator.of(context).pushNamed(Routes.symptomLog);
                },
              ),
              const SizedBox(height: 24),
              TodayInsights(
                cycleViewModel: cycleViewModel,
                fertilityViewModel: fertilityViewModel,
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildInsightsTab() {
    // Placeholder for Insights tab
    return const Center(
      child: Text('Insights Tab - Coming Soon'),
    );
  }

  Widget _buildLogTab() {
    // Placeholder for Log tab
    return const Center(
      child: Text('Log Tab - Coming Soon'),
    );
  }

  Widget _buildArticlesTab() {
    // Placeholder for Articles tab
    return const Center(
      child: Text('Articles Tab - Coming Soon'),
    );
  }

  Widget _buildProfileTab() {
    // Placeholder for Profile tab
    return const Center(
      child: Text('Profile Tab - Coming Soon'),
    );
  }
}
