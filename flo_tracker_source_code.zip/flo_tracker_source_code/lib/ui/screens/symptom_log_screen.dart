import 'package:flutter/material.dart';
import 'package:flo_tracker/config/theme.dart';
import 'package:flo_tracker/viewmodels/symptom_viewmodel.dart';
import 'package:provider/provider.dart';

class SymptomLogScreen extends StatefulWidget {
  final DateTime? date;

  const SymptomLogScreen({Key? key, this.date}) : super(key: key);

  @override
  State<SymptomLogScreen> createState() => _SymptomLogScreenState();
}

class _SymptomLogScreenState extends State<SymptomLogScreen> {
  late DateTime _selectedDate;
  String? _selectedSymptomId;
  int _selectedIntensity = 3;
  final TextEditingController _notesController = TextEditingController();

  @override
  void initState() {
    super.initState();
    _selectedDate = widget.date ?? DateTime.now();
  }

  @override
  void dispose() {
    _notesController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Log Symptoms'),
        centerTitle: true,
        elevation: 0,
      ),
      body: Consumer<SymptomViewModel>(
        builder: (context, symptomViewModel, _) {
          if (symptomViewModel.isLoading) {
            return const Center(child: CircularProgressIndicator());
          }

          final symptomsByCategory = symptomViewModel.symptomsByCategory;

          return SingleChildScrollView(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _buildDateSelector(),
                const SizedBox(height: 24),
                Text(
                  'Select Symptom',
                  style: Theme.of(context).textTheme.titleLarge,
                ),
                const SizedBox(height: 16),
                ...symptomsByCategory.entries.map((entry) {
                  return _buildCategorySection(
                    entry.key,
                    entry.value,
                    symptomViewModel,
                  );
                }),
                if (_selectedSymptomId != null) ...[
                  const SizedBox(height: 24),
                  Text(
                    'Intensity',
                    style: Theme.of(context).textTheme.titleLarge,
                  ),
                  const SizedBox(height: 16),
                  _buildIntensitySelector(),
                  const SizedBox(height: 24),
                  Text(
                    'Notes',
                    style: Theme.of(context).textTheme.titleLarge,
                  ),
                  const SizedBox(height: 16),
                  TextField(
                    controller: _notesController,
                    decoration: const InputDecoration(
                      hintText: 'Add notes (optional)',
                      border: OutlineInputBorder(),
                    ),
                    maxLines: 3,
                  ),
                  const SizedBox(height: 32),
                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      onPressed: () => _logSymptom(symptomViewModel),
                      child: const Text('Save'),
                    ),
                  ),
                ],
              ],
            ),
          );
        },
      ),
    );
  }

  Widget _buildDateSelector() {
    return InkWell(
      onTap: () async {
        final DateTime? picked = await showDatePicker(
          context: context,
          initialDate: _selectedDate,
          firstDate: DateTime.now().subtract(const Duration(days: 90)),
          lastDate: DateTime.now(),
        );
        if (picked != null) {
          setState(() {
            _selectedDate = picked;
          });
        }
      },
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: Theme.of(context).cardTheme.color,
          borderRadius: BorderRadius.circular(12),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.05),
              blurRadius: 10,
              offset: const Offset(0, 2),
            ),
          ],
        ),
        child: Row(
          children: [
            Icon(
              Icons.calendar_today,
              color: AppTheme.primaryColor,
            ),
            const SizedBox(width: 16),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Date',
                  style: Theme.of(context).textTheme.titleMedium,
                ),
                Text(
                  _formatDate(_selectedDate),
                  style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                        color: AppTheme.textSecondary,
                      ),
                ),
              ],
            ),
            const Spacer(),
            Icon(
              Icons.arrow_drop_down,
              color: AppTheme.textSecondary,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildCategorySection(
    String category,
    List<Symptom> symptoms,
    SymptomViewModel symptomViewModel,
  ) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          category,
          style: Theme.of(context).textTheme.titleMedium?.copyWith(
                color: AppTheme.textSecondary,
              ),
        ),
        const SizedBox(height: 8),
        Wrap(
          spacing: 8,
          runSpacing: 8,
          children: symptoms.map((symptom) {
            final isSelected = _selectedSymptomId == symptom.id;
            return _buildSymptomChip(symptom, isSelected);
          }).toList(),
        ),
        const SizedBox(height: 16),
      ],
    );
  }

  Widget _buildSymptomChip(Symptom symptom, bool isSelected) {
    return ChoiceChip(
      label: Text(symptom.name),
      selected: isSelected,
      onSelected: (selected) {
        setState(() {
          _selectedSymptomId = selected ? symptom.id : null;
        });
      },
      backgroundColor: Theme.of(context).cardTheme.color,
      selectedColor: AppTheme.primaryColor,
      labelStyle: TextStyle(
        color: isSelected ? Colors.white : AppTheme.textPrimary,
      ),
      avatar: symptom.isPremium
          ? Icon(
              Icons.star,
              size: 18,
              color: isSelected ? Colors.white : AppTheme.accentYellow,
            )
          : null,
    );
  }

  Widget _buildIntensitySelector() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Theme.of(context).cardTheme.color,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 10,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Text('Mild'),
              const Spacer(),
              const Text('Severe'),
            ],
          ),
          const SizedBox(height: 8),
          Slider(
            value: _selectedIntensity.toDouble(),
            min: 1,
            max: 5,
            divisions: 4,
            activeColor: AppTheme.primaryColor,
            inactiveColor: AppTheme.primaryLightColor,
            label: _selectedIntensity.toString(),
            onChanged: (value) {
              setState(() {
                _selectedIntensity = value.round();
              });
            },
          ),
          const SizedBox(height: 8),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: List.generate(5, (index) {
              final intensity = index + 1;
              return Container(
                width: 24,
                height: 24,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: intensity <= _selectedIntensity
                      ? AppTheme.primaryColor
                      : AppTheme.divider,
                ),
                child: Center(
                  child: Text(
                    intensity.toString(),
                    style: TextStyle(
                      color: intensity <= _selectedIntensity
                          ? Colors.white
                          : AppTheme.textSecondary,
                      fontSize: 12,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              );
            }),
          ),
        ],
      ),
    );
  }

  void _logSymptom(SymptomViewModel symptomViewModel) async {
    if (_selectedSymptomId == null) return;

    final success = await symptomViewModel.logSymptom(
      _selectedSymptomId!,
      _selectedDate,
      intensity: _selectedIntensity,
      notes: _notesController.text.isNotEmpty ? _notesController.text : null,
    );

    if (success && mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Symptom logged successfully'),
          backgroundColor: AppTheme.success,
        ),
      );
      Navigator.of(context).pop();
    } else if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(symptomViewModel.errorMessage ?? 'Failed to log symptom'),
          backgroundColor: AppTheme.error,
        ),
      );
    }
  }

  String _formatDate(DateTime date) {
    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);
    final yesterday = today.subtract(const Duration(days: 1));
    
    if (date.year == today.year && date.month == today.month && date.day == today.day) {
      return 'Today';
    } else if (date.year == yesterday.year && date.month == yesterday.month && date.day == yesterday.day) {
      return 'Yesterday';
    } else {
      return '${date.day}/${date.month}/${date.year}';
    }
  }
}
