import 'package:flutter/material.dart';
import 'package:flo_tracker/config/theme.dart';
import 'package:flo_tracker/viewmodels/cycle_viewmodel.dart';
import 'package:provider/provider.dart';

class PeriodLogDialog extends StatefulWidget {
  final bool isStartPeriod;
  final String? cycleId;

  const PeriodLogDialog({
    Key? key,
    required this.isStartPeriod,
    this.cycleId,
  }) : super(key: key);

  @override
  State<PeriodLogDialog> createState() => _PeriodLogDialogState();
}

class _PeriodLogDialogState extends State<PeriodLogDialog> {
  late DateTime _selectedDate;
  final TextEditingController _notesController = TextEditingController();

  @override
  void initState() {
    super.initState();
    _selectedDate = DateTime.now();
  }

  @override
  void dispose() {
    _notesController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Dialog(
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
      ),
      child: Padding(
        padding: const EdgeInsets.all(24.0),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              widget.isStartPeriod ? 'Log Period Start' : 'Log Period End',
              style: Theme.of(context).textTheme.headlineSmall,
            ),
            const SizedBox(height: 24),
            Text(
              'Date',
              style: Theme.of(context).textTheme.titleMedium,
            ),
            const SizedBox(height: 8),
            InkWell(
              onTap: () async {
                final DateTime? picked = await showDatePicker(
                  context: context,
                  initialDate: _selectedDate,
                  firstDate: DateTime.now().subtract(const Duration(days: 90)),
                  lastDate: DateTime.now(),
                );
                if (picked != null) {
                  setState(() {
                    _selectedDate = picked;
                  });
                }
              },
              child: Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  border: Border.all(color: AppTheme.divider),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Row(
                  children: [
                    Text(
                      _formatDate(_selectedDate),
                      style: Theme.of(context).textTheme.bodyLarge,
                    ),
                    const Spacer(),
                    Icon(
                      Icons.calendar_today,
                      color: AppTheme.primaryColor,
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 24),
            Text(
              'Notes (Optional)',
              style: Theme.of(context).textTheme.titleMedium,
            ),
            const SizedBox(height: 8),
            TextField(
              controller: _notesController,
              decoration: const InputDecoration(
                hintText: 'Add notes about your period',
                border: OutlineInputBorder(),
              ),
              maxLines: 3,
            ),
            const SizedBox(height: 24),
            Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                TextButton(
                  onPressed: () {
                    Navigator.of(context).pop();
                  },
                  child: const Text('Cancel'),
                ),
                const SizedBox(width: 16),
                ElevatedButton(
                  onPressed: () => _savePeriodLog(context),
                  child: const Text('Save'),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  void _savePeriodLog(BuildContext context) async {
    final cycleViewModel = Provider.of<CycleViewModel>(context, listen: false);
    bool success;

    if (widget.isStartPeriod) {
      success = await cycleViewModel.logPeriodStart(
        _selectedDate,
        notes: _notesController.text.isNotEmpty ? _notesController.text : null,
      );
    } else {
      if (widget.cycleId == null) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('No active cycle found'),
            backgroundColor: AppTheme.error,
          ),
        );
        return;
      }

      success = await cycleViewModel.logPeriodEnd(
        widget.cycleId!,
        _selectedDate,
        notes: _notesController.text.isNotEmpty ? _notesController.text : null,
      );
    }

    if (success && mounted) {
      Navigator.of(context).pop(true);
    } else if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(cycleViewModel.errorMessage ?? 'Failed to log period'),
          backgroundColor: AppTheme.error,
        ),
      );
    }
  }

  String _formatDate(DateTime date) {
    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);
    final yesterday = today.subtract(const Duration(days: 1));
    
    if (date.year == today.year && date.month == today.month && date.day == today.day) {
      return 'Today';
    } else if (date.year == yesterday.year && date.month == yesterday.month && date.day == yesterday.day) {
      return 'Yesterday';
    } else {
      return '${date.day}/${date.month}/${date.year}';
    }
  }
}
