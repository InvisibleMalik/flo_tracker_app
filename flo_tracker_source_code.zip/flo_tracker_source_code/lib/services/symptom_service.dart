import 'package:flo_tracker/models/symptom.dart';
import 'package:flo_tracker/models/user_symptom.dart';
import 'package:flo_tracker/services/database_helper.dart';
import 'package:flo_tracker/services/auth_service.dart';
import 'dart:async';
import 'package:uuid/uuid.dart';

class SymptomService {
  final DatabaseHelper _databaseHelper;
  final AuthService _authService;
  
  // Singleton pattern
  static final SymptomService _instance = SymptomService._internal();
  factory SymptomService() => _instance;
  
  SymptomService._internal() 
    : _databaseHelper = DatabaseHelper(),
      _authService = AuthService();
  
  // Stream to broadcast symptom data changes
  final _symptomDataController = StreamController<List<UserSymptom>>.broadcast();
  Stream<List<UserSymptom>> get symptomDataChanges => _symptomDataController.stream;
  
  // Error message
  String? _errorMessage;
  String? get errorMessage => _errorMessage;
  
  // Loading state
  bool _isLoading = false;
  bool get isLoading => _isLoading;
  
  // Symptom data
  List<Symptom> _symptoms = [];
  List<Symptom> get symptoms => _symptoms;
  
  Map<String, List<Symptom>> _symptomsByCategory = {};
  Map<String, List<Symptom>> get symptomsByCategory => _symptomsByCategory;
  
  List<UserSymptom> _userSymptoms = [];
  List<UserSymptom> get userSymptoms => _userSymptoms;
  
  // Initialize symptom service
  Future<void> initialize() async {
    _setLoading(true);
    
    try {
      // Load all predefined symptoms
      _symptoms = await _databaseHelper.getAllSymptoms();
      _symptomsByCategory = await _databaseHelper.getSymptomsByCategory();
      
      // Load user symptoms if user is logged in
      if (_authService.currentUser != null) {
        await _loadUserSymptoms();
      }
      
      _setLoading(false);
    } catch (e) {
      _setErrorMessage('Failed to initialize symptom data: ${e.toString()}');
      _setLoading(false);
    }
  }
  
  // Log a symptom
  Future<bool> logSymptom(String symptomId, DateTime date, {int? intensity, String? notes}) async {
    if (_authService.currentUser == null) {
      _setErrorMessage('No user logged in');
      return false;
    }
    
    try {
      // Find the symptom
      final symptom = _symptoms.firstWhere(
        (s) => s.id == symptomId,
        orElse: () => throw Exception('Symptom not found'),
      );
      
      // Check if symptom is premium and user has premium access
      if (symptom.isPremium && !(_authService.currentUser?.premiumStatus ?? false)) {
        _setErrorMessage('This symptom requires premium access');
        return false;
      }
      
      // Create user symptom
      final userSymptom = UserSymptom(
        userId: _authService.currentUser!.id,
        symptomId: symptomId,
        date: date,
        intensity: intensity,
        notes: notes,
        symptomName: symptom.name,
        category: symptom.category,
      );
      
      await _databaseHelper.insertUserSymptom(userSymptom);
      
      // Reload user symptoms
      await _loadUserSymptoms();
      
      return true;
    } catch (e) {
      _setErrorMessage('Failed to log symptom: ${e.toString()}');
      return false;
    }
  }
  
  // Delete a user symptom
  Future<bool> deleteSymptom(String userSymptomId) async {
    if (_authService.currentUser == null) {
      _setErrorMessage('No user logged in');
      return false;
    }
    
    try {
      await _databaseHelper.deleteUserSymptom(userSymptomId);
      
      // Reload user symptoms
      await _loadUserSymptoms();
      
      return true;
    } catch (e) {
      _setErrorMessage('Failed to delete symptom: ${e.toString()}');
      return false;
    }
  }
  
  // Get symptoms for a specific date
  List<UserSymptom> getSymptomsForDate(DateTime date) {
    final normalizedDate = DateTime(date.year, date.month, date.day);
    
    return _userSymptoms.where((symptom) {
      final symptomDate = DateTime(
        symptom.date.year,
        symptom.date.month,
        symptom.date.day,
      );
      
      return symptomDate.isAtSameMomentAs(normalizedDate);
    }).toList();
  }
  
  // Helper methods
  Future<void> _loadUserSymptoms() async {
    if (_authService.currentUser == null) {
      return;
    }
    
    // Load user symptoms for the last 90 days
    final today = DateTime.now();
    final ninetyDaysAgo = today.subtract(const Duration(days: 90));
    
    _userSymptoms = await _databaseHelper.getUserSymptomsForDateRange(
      _authService.currentUser!.id,
      ninetyDaysAgo,
      today,
    );
    
    // Enrich user symptoms with symptom name and category
    for (var i = 0; i < _userSymptoms.length; i++) {
      final userSymptom = _userSymptoms[i];
      
      // Find the corresponding symptom
      final symptom = _symptoms.firstWhere(
        (s) => s.id == userSymptom.symptomId,
        orElse: () => Symptom(
          id: userSymptom.symptomId,
          name: 'Unknown',
          category: 'Other',
        ),
      );
      
      // Update user symptom with symptom name and category
      _userSymptoms[i] = userSymptom.copyWith(
        symptomName: symptom.name,
        category: symptom.category,
      );
    }
    
    // Notify listeners
    _symptomDataController.add(_userSymptoms);
  }
  
  void _setLoading(bool loading) {
    _isLoading = loading;
  }
  
  void _setErrorMessage(String? message) {
    _errorMessage = message;
  }
  
  void clearError() {
    _errorMessage = null;
  }
  
  // Dispose
  void dispose() {
    _symptomDataController.close();
  }
}
