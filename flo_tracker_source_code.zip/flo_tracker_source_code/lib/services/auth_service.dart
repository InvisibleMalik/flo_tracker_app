import 'package:firebase_auth/firebase_auth.dart' as firebase_auth;
import 'package:flo_tracker/models/user.dart' as app_models;
import 'package:flo_tracker/services/database_helper.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:async';

enum AuthStatus {
  initial,
  authenticating,
  authenticated,
  unauthenticated,
  error,
}

class AuthService {
  final firebase_auth.FirebaseAuth _firebaseAuth;
  final DatabaseHelper _databaseHelper;
  
  // Singleton pattern
  static final AuthService _instance = AuthService._internal();
  factory AuthService() => _instance;
  
  AuthService._internal() 
    : _firebaseAuth = firebase_auth.FirebaseAuth.instance,
      _databaseHelper = DatabaseHelper();
  
  // Stream to broadcast auth state changes
  final _authStateController = StreamController<AuthStatus>.broadcast();
  Stream<AuthStatus> get authStateChanges => _authStateController.stream;
  
  // Current user
  app_models.User? _currentUser;
  app_models.User? get currentUser => _currentUser;
  
  // Error message
  String? _errorMessage;
  String? get errorMessage => _errorMessage;
  
  // Auth status
  AuthStatus _status = AuthStatus.initial;
  AuthStatus get status => _status;
  
  // Initialize auth service
  Future<void> initialize() async {
    _updateStatus(AuthStatus.initial);
    
    // Check if user is already logged in
    firebase_auth.User? firebaseUser = _firebaseAuth.currentUser;
    
    if (firebaseUser != null) {
      try {
        await _loadUserData(firebaseUser.uid);
        _updateStatus(AuthStatus.authenticated);
      } catch (e) {
        _updateStatus(AuthStatus.unauthenticated);
        _setErrorMessage('Failed to load user data: ${e.toString()}');
      }
    } else {
      // Check if we have a locally stored anonymous user
      final prefs = await SharedPreferences.getInstance();
      final anonymousUserId = prefs.getString('anonymous_user_id');
      
      if (anonymousUserId != null) {
        try {
          await _loadUserData(anonymousUserId);
          _updateStatus(AuthStatus.authenticated);
        } catch (e) {
          _updateStatus(AuthStatus.unauthenticated);
          _setErrorMessage('Failed to load anonymous user data: ${e.toString()}');
        }
      } else {
        _updateStatus(AuthStatus.unauthenticated);
      }
    }
  }
  
  // Register with email and password
  Future<bool> registerWithEmailAndPassword(String email, String password, String name) async {
    try {
      _updateStatus(AuthStatus.authenticating);
      _clearErrorMessage();
      
      // Create user in Firebase
      final userCredential = await _firebaseAuth.createUserWithEmailAndPassword(
        email: email,
        password: password,
      );
      
      final firebaseUser = userCredential.user;
      if (firebaseUser == null) {
        _updateStatus(AuthStatus.error);
        _setErrorMessage('Failed to create user');
        return false;
      }
      
      // Create user in local database
      final user = app_models.User(
        id: firebaseUser.uid,
        name: name,
        email: email,
        isAnonymous: false,
      );
      
      await _databaseHelper.insertUser(user);
      _currentUser = user;
      
      _updateStatus(AuthStatus.authenticated);
      return true;
    } catch (e) {
      _updateStatus(AuthStatus.error);
      _setErrorMessage(_handleFirebaseAuthError(e));
      return false;
    }
  }
  
  // Login with email and password
  Future<bool> loginWithEmailAndPassword(String email, String password) async {
    try {
      _updateStatus(AuthStatus.authenticating);
      _clearErrorMessage();
      
      final userCredential = await _firebaseAuth.signInWithEmailAndPassword(
        email: email,
        password: password,
      );
      
      final firebaseUser = userCredential.user;
      if (firebaseUser == null) {
        _updateStatus(AuthStatus.error);
        _setErrorMessage('Failed to sign in');
        return false;
      }
      
      await _loadUserData(firebaseUser.uid);
      _updateStatus(AuthStatus.authenticated);
      return true;
    } catch (e) {
      _updateStatus(AuthStatus.error);
      _setErrorMessage(_handleFirebaseAuthError(e));
      return false;
    }
  }
  
  // Login anonymously
  Future<bool> loginAnonymously() async {
    try {
      _updateStatus(AuthStatus.authenticating);
      _clearErrorMessage();
      
      // Create anonymous user in local database
      final user = app_models.User(
        isAnonymous: true,
      );
      
      await _databaseHelper.insertUser(user);
      _currentUser = user;
      
      // Store anonymous user ID in shared preferences
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString('anonymous_user_id', user.id);
      
      _updateStatus(AuthStatus.authenticated);
      return true;
    } catch (e) {
      _updateStatus(AuthStatus.error);
      _setErrorMessage('Failed to create anonymous user: ${e.toString()}');
      return false;
    }
  }
  
  // Convert anonymous account to permanent account
  Future<bool> convertAnonymousAccount(String email, String password, String name) async {
    if (_currentUser == null || !_currentUser!.isAnonymous) {
      _setErrorMessage('No anonymous account to convert');
      return false;
    }
    
    try {
      _updateStatus(AuthStatus.authenticating);
      _clearErrorMessage();
      
      // Create user in Firebase
      final userCredential = await _firebaseAuth.createUserWithEmailAndPassword(
        email: email,
        password: password,
      );
      
      final firebaseUser = userCredential.user;
      if (firebaseUser == null) {
        _updateStatus(AuthStatus.error);
        _setErrorMessage('Failed to create user');
        return false;
      }
      
      // Update user in local database
      final updatedUser = _currentUser!.copyWith(
        name: name,
        email: email,
        isAnonymous: false,
      );
      
      await _databaseHelper.updateUser(updatedUser);
      _currentUser = updatedUser;
      
      // Remove anonymous user ID from shared preferences
      final prefs = await SharedPreferences.getInstance();
      await prefs.remove('anonymous_user_id');
      
      _updateStatus(AuthStatus.authenticated);
      return true;
    } catch (e) {
      _updateStatus(AuthStatus.error);
      _setErrorMessage(_handleFirebaseAuthError(e));
      return false;
    }
  }
  
  // Logout
  Future<void> logout() async {
    try {
      if (!(_currentUser?.isAnonymous ?? true)) {
        await _firebaseAuth.signOut();
      }
      
      _currentUser = null;
      _updateStatus(AuthStatus.unauthenticated);
      
      // Remove anonymous user ID from shared preferences if it exists
      final prefs = await SharedPreferences.getInstance();
      await prefs.remove('anonymous_user_id');
    } catch (e) {
      _setErrorMessage('Failed to logout: ${e.toString()}');
    }
  }
  
  // Update user profile
  Future<bool> updateUserProfile({
    String? name,
    int? cycleLength,
    int? periodLength,
  }) async {
    if (_currentUser == null) {
      _setErrorMessage('No user logged in');
      return false;
    }
    
    try {
      final updatedUser = _currentUser!.copyWith(
        name: name,
        cycleLength: cycleLength,
        periodLength: periodLength,
      );
      
      await _databaseHelper.updateUser(updatedUser);
      _currentUser = updatedUser;
      
      return true;
    } catch (e) {
      _setErrorMessage('Failed to update profile: ${e.toString()}');
      return false;
    }
  }
  
  // Reset password
  Future<bool> resetPassword(String email) async {
    try {
      _clearErrorMessage();
      await _firebaseAuth.sendPasswordResetEmail(email: email);
      return true;
    } catch (e) {
      _setErrorMessage(_handleFirebaseAuthError(e));
      return false;
    }
  }
  
  // Helper methods
  Future<void> _loadUserData(String userId) async {
    final user = await _databaseHelper.getUser(userId);
    
    if (user != null) {
      // Update last login time
      final updatedUser = user.copyWith(
        lastLogin: DateTime.now(),
      );
      
      await _databaseHelper.updateUser(updatedUser);
      _currentUser = updatedUser;
    } else {
      throw Exception('User not found in local database');
    }
  }
  
  void _updateStatus(AuthStatus status) {
    _status = status;
    _authStateController.add(status);
  }
  
  void _setErrorMessage(String message) {
    _errorMessage = message;
  }
  
  void _clearErrorMessage() {
    _errorMessage = null;
  }
  
  String _handleFirebaseAuthError(dynamic error) {
    if (error is firebase_auth.FirebaseAuthException) {
      switch (error.code) {
        case 'invalid-email':
          return 'The email address is not valid.';
        case 'user-disabled':
          return 'This user has been disabled.';
        case 'user-not-found':
          return 'No user found with this email.';
        case 'wrong-password':
          return 'The password is invalid.';
        case 'email-already-in-use':
          return 'The email address is already in use.';
        case 'operation-not-allowed':
          return 'This operation is not allowed.';
        case 'weak-password':
          return 'The password is too weak.';
        default:
          return 'Authentication failed: ${error.message}';
      }
    }
    return 'Authentication failed: ${error.toString()}';
  }
  
  // Dispose
  void dispose() {
    _authStateController.close();
  }
}
