import 'package:flo_tracker/models/fertility_data.dart';
import 'package:flo_tracker/services/database_helper.dart';
import 'package:flo_tracker/services/auth_service.dart';
import 'package:flo_tracker/services/cycle_service.dart';
import 'dart:async';

class FertilityService {
  final DatabaseHelper _databaseHelper;
  final AuthService _authService;
  final CycleService _cycleService;
  
  // Singleton pattern
  static final FertilityService _instance = FertilityService._internal();
  factory FertilityService() => _instance;
  
  FertilityService._internal() 
    : _databaseHelper = DatabaseHelper(),
      _authService = AuthService(),
      _cycleService = CycleService();
  
  // Stream to broadcast fertility data changes
  final _fertilityDataController = StreamController<List<FertilityData>>.broadcast();
  Stream<List<FertilityData>> get fertilityDataChanges => _fertilityDataController.stream;
  
  // Error message
  String? _errorMessage;
  String? get errorMessage => _errorMessage;
  
  // Loading state
  bool _isLoading = false;
  bool get isLoading => _isLoading;
  
  // Fertility data
  List<FertilityData> _fertilityData = [];
  List<FertilityData> get fertilityData => _fertilityData;
  
  List<FertilityData> _fertilityPredictions = [];
  List<FertilityData> get fertilityPredictions => _fertilityPredictions;
  
  // Initialize fertility service
  Future<void> initialize() async {
    if (_authService.currentUser == null) {
      _setErrorMessage('No user logged in');
      return;
    }
    
    _setLoading(true);
    
    try {
      await _loadFertilityData();
      await _generateFertilityPredictions();
      _setLoading(false);
    } catch (e) {
      _setErrorMessage('Failed to initialize fertility data: ${e.toString()}');
      _setLoading(false);
    }
  }
  
  // Log fertility data
  Future<bool> logFertilityData(
    DateTime date, {
    double? basalBodyTemperature,
    String? cervicalMucusType,
    String? ovulationTestResult,
    String? notes,
  }) async {
    if (_authService.currentUser == null) {
      _setErrorMessage('No user logged in');
      return false;
    }
    
    try {
      // Check if data already exists for this date
      final existingData = await _databaseHelper.getFertilityDataForDate(
        _authService.currentUser!.id,
        date,
      );
      
      if (existingData != null) {
        // Update existing data
        final updatedData = existingData.copyWith(
          basalBodyTemperature: basalBodyTemperature ?? existingData.basalBodyTemperature,
          cervicalMucusType: cervicalMucusType ?? existingData.cervicalMucusType,
          ovulationTestResult: ovulationTestResult ?? existingData.ovulationTestResult,
          notes: notes ?? existingData.notes,
        );
        
        await _databaseHelper.updateFertilityData(updatedData);
      } else {
        // Create new fertility data
        final fertilityData = FertilityData(
          userId: _authService.currentUser!.id,
          date: date,
          basalBodyTemperature: basalBodyTemperature,
          cervicalMucusType: cervicalMucusType,
          ovulationTestResult: ovulationTestResult,
          notes: notes,
        );
        
        await _databaseHelper.insertFertilityData(fertilityData);
      }
      
      // Reload fertility data
      await _loadFertilityData();
      await _updateFertilityStatus();
      
      return true;
    } catch (e) {
      _setErrorMessage('Failed to log fertility data: ${e.toString()}');
      return false;
    }
  }
  
  // Get fertility data for a specific date
  FertilityData? getFertilityDataForDate(DateTime date) {
    final normalizedDate = DateTime(date.year, date.month, date.day);
    
    // First check actual data
    for (final data in _fertilityData) {
      final dataDate = DateTime(
        data.date.year,
        data.date.month,
        data.date.day,
      );
      
      if (dataDate.isAtSameMomentAs(normalizedDate)) {
        return data;
      }
    }
    
    // Then check predictions
    for (final prediction in _fertilityPredictions) {
      final predictionDate = DateTime(
        prediction.date.year,
        prediction.date.month,
        prediction.date.day,
      );
      
      if (predictionDate.isAtSameMomentAs(normalizedDate)) {
        return prediction;
      }
    }
    
    return null;
  }
  
  // Check if today is a fertile day
  bool get isTodayFertileDay {
    final today = DateTime.now();
    final normalizedToday = DateTime(today.year, today.month, today.day);
    
    final todayData = getFertilityDataForDate(normalizedToday);
    return todayData?.isFertileDay ?? false;
  }
  
  // Check if today is ovulation day
  bool get isTodayOvulationDay {
    final today = DateTime.now();
    final normalizedToday = DateTime(today.year, today.month, today.day);
    
    final todayData = getFertilityDataForDate(normalizedToday);
    return todayData?.isOvulationDay ?? false;
  }
  
  // Helper methods
  Future<void> _loadFertilityData() async {
    if (_authService.currentUser == null) {
      return;
    }
    
    // Load fertility data for the last 90 days
    final today = DateTime.now();
    final ninetyDaysAgo = today.subtract(const Duration(days: 90));
    
    _fertilityData = await _databaseHelper.getFertilityDataForDateRange(
      _authService.currentUser!.id,
      ninetyDaysAgo,
      today,
    );
    
    // Notify listeners
    _fertilityDataController.add(_fertilityData);
  }
  
  Future<void> _generateFertilityPredictions() async {
    if (_authService.currentUser == null) {
      return;
    }
    
    // Clear existing predictions
    _fertilityPredictions = [];
    
    // Get cycle predictions
    final cyclePredictions = _cycleService.predictions;
    if (cyclePredictions.isEmpty) {
      return;
    }
    
    // For each predicted cycle, calculate fertile window and ovulation day
    for (final cycle in cyclePredictions) {
      final cycleLength = _authService.currentUser!.cycleLength;
      
      // Ovulation typically occurs 14 days before the next period
      final ovulationDate = cycle.startDate.subtract(const Duration(days: 14));
      
      // Fertile window is typically 5 days before ovulation and the day of ovulation
      final fertileWindowStart = ovulationDate.subtract(const Duration(days: 5));
      final fertileWindowEnd = ovulationDate;
      
      // Create fertility predictions for the fertile window
      for (int i = 0; i <= 5; i++) {
        final date = fertileWindowStart.add(Duration(days: i));
        final isOvulationDay = date.isAtSameMomentAs(ovulationDate);
        
        final fertilityPrediction = FertilityData(
          userId: _authService.currentUser!.id,
          date: date,
          isFertileDay: true,
          isOvulationDay: isOvulationDay,
        );
        
        _fertilityPredictions.add(fertilityPrediction);
      }
    }
  }
  
  Future<void> _updateFertilityStatus() async {
    if (_authService.currentUser == null || _fertilityData.isEmpty) {
      return;
    }
    
    // Sort fertility data by date
    _fertilityData.sort((a, b) => a.date.compareTo(b.date));
    
    // Analyze BBT data to detect ovulation
    // A sustained rise in BBT of at least 0.2°C for 3 consecutive days indicates ovulation
    for (int i = 2; i < _fertilityData.length; i++) {
      if (_fertilityData[i].basalBodyTemperature == null ||
          _fertilityData[i - 1].basalBodyTemperature == null ||
          _fertilityData[i - 2].basalBodyTemperature == null) {
        continue;
      }
      
      final temp1 = _fertilityData[i - 2].basalBodyTemperature!;
      final temp2 = _fertilityData[i - 1].basalBodyTemperature!;
      final temp3 = _fertilityData[i].basalBodyTemperature!;
      
      if (temp2 > temp1 + 0.1 && temp3 > temp1 + 0.2) {
        // Sustained rise detected, mark the day before the rise as ovulation day
        final ovulationDate = _fertilityData[i - 2].date;
        
        // Update fertility data for ovulation day
        final ovulationData = _fertilityData.firstWhere(
          (data) => data.date.isAtSameMomentAs(ovulationDate),
          orElse: () => FertilityData(
            userId: _authService.currentUser!.id,
            date: ovulationDate,
          ),
        );
        
        final updatedOvulationData = ovulationData.copyWith(
          isOvulationDay: true,
          isFertileDay: true,
        );
        
        await _databaseHelper.updateFertilityData(updatedOvulationData);
        
        // Update fertility data for fertile window (5 days before ovulation)
        for (int j = 1; j <= 5; j++) {
          final fertileDate = ovulationDate.subtract(Duration(days: j));
          
          final fertileData = _fertilityData.firstWhere(
            (data) => data.date.isAtSameMomentAs(fertileDate),
            orElse: () => FertilityData(
              userId: _authService.currentUser!.id,
              date: fertileDate,
            ),
          );
          
          final updatedFertileData = fertileData.copyWith(
            isFertileDay: true,
          );
          
          await _databaseHelper.updateFertilityData(updatedFertileData);
        }
      }
    }
    
    // Analyze cervical mucus data
    // Egg-white or watery cervical mucus indicates fertility
    for (final data in _fertilityData) {
      if (data.cervicalMucusType == 'egg-white' || data.cervicalMucusType == 'watery') {
        final updatedData = data.copyWith(
          isFertileDay: true,
        );
        
        await _databaseHelper.updateFertilityData(updatedData);
      }
    }
    
    // Analyze ovulation test results
    // Positive ovulation test indicates fertility and imminent ovulation
    for (final data in _fertilityData) {
      if (data.ovulationTestResult == 'positive') {
        final updatedData = data.copyWith(
          isFertileDay: true,
          // Ovulation typically occurs 24-48 hours after a positive test
          isOvulationDay: false,
        );
        
        await _databaseHelper.updateFertilityData(updatedData);
        
        // Mark the next 2 days as potential ovulation days
        for (int j = 1; j <= 2; j++) {
          final ovulationDate = data.date.add(Duration(days: j));
          
          final ovulationData = _fertilityData.firstWhere(
            (d) => d.date.isAtSameMomentAs(ovulationDate),
            orElse: () => FertilityData(
              userId: _authService.currentUser!.id,
              date: ovulationDate,
            ),
          );
          
          final updatedOvulationData = ovulationData.copyWith(
            isFertileDay: true,
            isOvulationDay: true,
          );
          
          await _databaseHelper.updateFertilityData(updatedOvulationData);
        }
      }
    }
    
    // Reload fertility data
    await _loadFertilityData();
  }
  
  void _setLoading(bool loading) {
    _isLoading = loading;
  }
  
  void _setErrorMessage(String? message) {
    _errorMessage = message;
  }
  
  void clearError() {
    _errorMessage = null;
  }
  
  // Dispose
  void dispose() {
    _fertilityDataController.close();
  }
}
