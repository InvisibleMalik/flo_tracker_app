import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';
import 'dart:async';
import 'package:flo_tracker/models/user.dart';
import 'package:flo_tracker/models/cycle.dart';
import 'package:flo_tracker/models/symptom.dart';
import 'package:flo_tracker/models/user_symptom.dart';
import 'package:flo_tracker/models/fertility_data.dart';

class DatabaseHelper {
  static final DatabaseHelper _instance = DatabaseHelper._internal();
  factory DatabaseHelper() => _instance;
  DatabaseHelper._internal();

  static Database? _database;

  Future<Database> get database async {
    if (_database != null) return _database!;
    _database = await _initDatabase();
    return _database!;
  }

  Future<Database> _initDatabase() async {
    String path = join(await getDatabasesPath(), 'flo_tracker.db');
    return await openDatabase(
      path,
      version: 1,
      onCreate: _createDatabase,
    );
  }

  Future<void> _createDatabase(Database db, int version) async {
    // Users table
    await db.execute('''
      CREATE TABLE users (
        id TEXT PRIMARY KEY,
        name TEXT,
        email TEXT,
        created_at INTEGER,
        last_login INTEGER,
        is_anonymous INTEGER,
        cycle_length INTEGER DEFAULT 28,
        period_length INTEGER DEFAULT 5,
        premium_status INTEGER DEFAULT 0
      )
    ''');

    // Cycles table
    await db.execute('''
      CREATE TABLE cycles (
        id TEXT PRIMARY KEY,
        user_id TEXT,
        start_date INTEGER,
        end_date INTEGER,
        notes TEXT,
        is_prediction INTEGER DEFAULT 0,
        FOREIGN KEY (user_id) REFERENCES users (id)
      )
    ''');

    // Symptoms table (predefined symptoms)
    await db.execute('''
      CREATE TABLE symptoms (
        id TEXT PRIMARY KEY,
        name TEXT,
        category TEXT,
        description TEXT,
        is_premium INTEGER DEFAULT 0
      )
    ''');

    // User symptoms (logged symptoms)
    await db.execute('''
      CREATE TABLE user_symptoms (
        id TEXT PRIMARY KEY,
        user_id TEXT,
        symptom_id TEXT,
        date INTEGER,
        intensity INTEGER,
        notes TEXT,
        FOREIGN KEY (user_id) REFERENCES users (id),
        FOREIGN KEY (symptom_id) REFERENCES symptoms (id)
      )
    ''');

    // Fertility data
    await db.execute('''
      CREATE TABLE fertility_data (
        id TEXT PRIMARY KEY,
        user_id TEXT,
        date INTEGER,
        basal_body_temperature REAL,
        cervical_mucus_type TEXT,
        ovulation_test_result TEXT,
        is_fertile_day INTEGER DEFAULT 0,
        is_ovulation_day INTEGER DEFAULT 0,
        notes TEXT,
        FOREIGN KEY (user_id) REFERENCES users (id)
      )
    ''');

    // Insert predefined symptoms
    await _insertPredefinedSymptoms(db);
  }

  Future<void> _insertPredefinedSymptoms(Database db) async {
    // Mood symptoms
    await db.insert('symptoms', {
      'id': 'mood_happy',
      'name': 'Happy',
      'category': 'Mood',
      'description': 'Feeling happy or content',
      'is_premium': 0
    });
    await db.insert('symptoms', {
      'id': 'mood_sad',
      'name': 'Sad',
      'category': 'Mood',
      'description': 'Feeling sad or down',
      'is_premium': 0
    });
    await db.insert('symptoms', {
      'id': 'mood_anxious',
      'name': 'Anxious',
      'category': 'Mood',
      'description': 'Feeling anxious or worried',
      'is_premium': 0
    });
    await db.insert('symptoms', {
      'id': 'mood_irritable',
      'name': 'Irritable',
      'category': 'Mood',
      'description': 'Feeling irritable or easily annoyed',
      'is_premium': 0
    });
    await db.insert('symptoms', {
      'id': 'mood_mood_swings',
      'name': 'Mood Swings',
      'category': 'Mood',
      'description': 'Experiencing rapid mood changes',
      'is_premium': 0
    });

    // Pain symptoms
    await db.insert('symptoms', {
      'id': 'pain_cramps',
      'name': 'Cramps',
      'category': 'Pain',
      'description': 'Abdominal or pelvic cramps',
      'is_premium': 0
    });
    await db.insert('symptoms', {
      'id': 'pain_headache',
      'name': 'Headache',
      'category': 'Pain',
      'description': 'Head pain or discomfort',
      'is_premium': 0
    });
    await db.insert('symptoms', {
      'id': 'pain_backache',
      'name': 'Backache',
      'category': 'Pain',
      'description': 'Back pain or discomfort',
      'is_premium': 0
    });
    await db.insert('symptoms', {
      'id': 'pain_breast_tenderness',
      'name': 'Breast Tenderness',
      'category': 'Pain',
      'description': 'Sensitive or painful breasts',
      'is_premium': 0
    });
    await db.insert('symptoms', {
      'id': 'pain_ovulation',
      'name': 'Ovulation Pain',
      'category': 'Pain',
      'description': 'Pain during ovulation (mittelschmerz)',
      'is_premium': 0
    });

    // Discharge symptoms
    await db.insert('symptoms', {
      'id': 'discharge_spotting',
      'name': 'Spotting',
      'category': 'Discharge',
      'description': 'Light bleeding outside of period',
      'is_premium': 0
    });
    await db.insert('symptoms', {
      'id': 'discharge_light_flow',
      'name': 'Light Flow',
      'category': 'Discharge',
      'description': 'Light menstrual flow',
      'is_premium': 0
    });
    await db.insert('symptoms', {
      'id': 'discharge_medium_flow',
      'name': 'Medium Flow',
      'category': 'Discharge',
      'description': 'Medium menstrual flow',
      'is_premium': 0
    });
    await db.insert('symptoms', {
      'id': 'discharge_heavy_flow',
      'name': 'Heavy Flow',
      'category': 'Discharge',
      'description': 'Heavy menstrual flow',
      'is_premium': 0
    });
    await db.insert('symptoms', {
      'id': 'discharge_egg_white',
      'name': 'Egg White',
      'category': 'Discharge',
      'description': 'Clear, stretchy cervical mucus',
      'is_premium': 0
    });

    // Body symptoms
    await db.insert('symptoms', {
      'id': 'body_bloating',
      'name': 'Bloating',
      'category': 'Body',
      'description': 'Feeling of fullness or swelling in abdomen',
      'is_premium': 0
    });
    await db.insert('symptoms', {
      'id': 'body_fatigue',
      'name': 'Fatigue',
      'category': 'Body',
      'description': 'Feeling tired or exhausted',
      'is_premium': 0
    });
    await db.insert('symptoms', {
      'id': 'body_insomnia',
      'name': 'Insomnia',
      'category': 'Body',
      'description': 'Difficulty sleeping',
      'is_premium': 0
    });
    await db.insert('symptoms', {
      'id': 'body_acne',
      'name': 'Acne',
      'category': 'Body',
      'description': 'Skin breakouts',
      'is_premium': 0
    });
    await db.insert('symptoms', {
      'id': 'body_cravings',
      'name': 'Cravings',
      'category': 'Body',
      'description': 'Food cravings',
      'is_premium': 0
    });

    // Premium symptoms
    await db.insert('symptoms', {
      'id': 'premium_libido_high',
      'name': 'High Libido',
      'category': 'Intimate',
      'description': 'Increased sexual desire',
      'is_premium': 1
    });
    await db.insert('symptoms', {
      'id': 'premium_libido_low',
      'name': 'Low Libido',
      'category': 'Intimate',
      'description': 'Decreased sexual desire',
      'is_premium': 1
    });
    await db.insert('symptoms', {
      'id': 'premium_protected_sex',
      'name': 'Protected Sex',
      'category': 'Intimate',
      'description': 'Sexual intercourse with protection',
      'is_premium': 1
    });
    await db.insert('symptoms', {
      'id': 'premium_unprotected_sex',
      'name': 'Unprotected Sex',
      'category': 'Intimate',
      'description': 'Sexual intercourse without protection',
      'is_premium': 1
    });
  }

  // User methods
  Future<int> insertUser(User user) async {
    Database db = await database;
    return await db.insert('users', user.toMap());
  }

  Future<User?> getUser(String id) async {
    Database db = await database;
    List<Map<String, dynamic>> maps = await db.query(
      'users',
      where: 'id = ?',
      whereArgs: [id],
    );

    if (maps.isNotEmpty) {
      return User.fromMap(maps.first);
    }
    return null;
  }

  Future<int> updateUser(User user) async {
    Database db = await database;
    return await db.update(
      'users',
      user.toMap(),
      where: 'id = ?',
      whereArgs: [user.id],
    );
  }

  // Cycle methods
  Future<int> insertCycle(Cycle cycle) async {
    Database db = await database;
    return await db.insert('cycles', cycle.toMap());
  }

  Future<List<Cycle>> getUserCycles(String userId) async {
    Database db = await database;
    List<Map<String, dynamic>> maps = await db.query(
      'cycles',
      where: 'user_id = ? AND is_prediction = 0',
      whereArgs: [userId],
      orderBy: 'start_date DESC',
    );

    return List.generate(maps.length, (i) {
      return Cycle.fromMap(maps[i]);
    });
  }

  Future<List<Cycle>> getUserCyclePredictions(String userId) async {
    Database db = await database;
    List<Map<String, dynamic>> maps = await db.query(
      'cycles',
      where: 'user_id = ? AND is_prediction = 1',
      whereArgs: [userId],
      orderBy: 'start_date ASC',
    );

    return List.generate(maps.length, (i) {
      return Cycle.fromMap(maps[i]);
    });
  }

  Future<Cycle?> getCurrentCycle(String userId) async {
    Database db = await database;
    List<Map<String, dynamic>> maps = await db.query(
      'cycles',
      where: 'user_id = ? AND is_prediction = 0 AND (end_date IS NULL OR end_date > ?)',
      whereArgs: [userId, DateTime.now().millisecondsSinceEpoch],
      orderBy: 'start_date DESC',
      limit: 1,
    );

    if (maps.isNotEmpty) {
      return Cycle.fromMap(maps.first);
    }
    return null;
  }

  Future<int> updateCycle(Cycle cycle) async {
    Database db = await database;
    return await db.update(
      'cycles',
      cycle.toMap(),
      where: 'id = ?',
      whereArgs: [cycle.id],
    );
  }

  // Symptom methods
  Future<List<Symptom>> getAllSymptoms() async {
    Database db = await database;
    List<Map<String, dynamic>> maps = await db.query(
      'symptoms',
      orderBy: 'category ASC, name ASC',
    );

    return List.generate(maps.length, (i) {
      return Symptom.fromMap(maps[i]);
    });
  }

  Future<Map<String, List<Symptom>>> getSymptomsByCategory() async {
    List<Symptom> allSymptoms = await getAllSymptoms();
    Map<String, List<Symptom>> result = {};

    for (var symptom in allSymptoms) {
      if (!result.containsKey(symptom.category)) {
        result[symptom.category] = [];
      }
      result[symptom.category]!.add(symptom);
    }

    return result;
  }

  // User symptom methods
  Future<int> insertUserSymptom(UserSymptom userSymptom) async {
    Database db = await database;
    return await db.insert('user_symptoms', userSymptom.toMap());
  }

  Future<List<UserSymptom>> getUserSymptomsForDate(String userId, DateTime date) async {
    Database db = await database;
    DateTime startOfDay = DateTime(date.year, date.month, date.day);
    DateTime endOfDay = DateTime(date.year, date.month, date.day, 23, 59, 59);

    List<Map<String, dynamic>> maps = await db.query(
      'user_symptoms',
      where: 'user_id = ? AND date >= ? AND date <= ?',
      whereArgs: [
        userId,
        startOfDay.millisecondsSinceEpoch,
        endOfDay.millisecondsSinceEpoch,
      ],
    );

    return List.generate(maps.length, (i) {
      return UserSymptom.fromMap(maps[i]);
    });
  }

  Future<List<UserSymptom>> getUserSymptomsForDateRange(
      String userId, DateTime startDate, DateTime endDate) async {
    Database db = await database;
    DateTime startOfDay = DateTime(startDate.year, startDate.month, startDate.day);
    DateTime endOfDay = DateTime(endDate.year, endDate.month, endDate.day, 23, 59, 59);

    List<Map<String, dynamic>> maps = await db.query(
      'user_symptoms',
      where: 'user_id = ? AND date >= ? AND date <= ?',
      whereArgs: [
        userId,
        startOfDay.millisecondsSinceEpoch,
        endOfDay.millisecondsSinceEpoch,
      ],
    );

    return List.generate(maps.length, (i) {
      return UserSymptom.fromMap(maps[i]);
    });
  }

  Future<int> deleteUserSymptom(String id) async {
    Database db = await database;
    return await db.delete(
      'user_symptoms',
      where: 'id = ?',
      whereArgs: [id],
    );
  }

  // Fertility data methods
  Future<int> insertFertilityData(FertilityData fertilityData) async {
    Database db = await database;
    return await db.insert('fertility_data', fertilityData.toMap());
  }

  Future<FertilityData?> getFertilityDataForDate(String userId, DateTime date) async {
    Database db = await database;
    DateTime startOfDay = DateTime(date.year, date.month, date.day);
    DateTime endOfDay = DateTime(date.year, date.month, date.day, 23, 59, 59);

    List<Map<String, dynamic>> maps = await db.query(
      'fertility_data',
      where: 'user_id = ? AND date >= ? AND date <= ?',
      whereArgs: [
        userId,
        startOfDay.millisecondsSinceEpoch,
        endOfDay.millisecondsSinceEpoch,
      ],
    );

    if (maps.isNotEmpty) {
      return FertilityData.fromMap(maps.first);
    }
    return null;
  }

  Future<List<FertilityData>> getFertilityDataForDateRange(
      String userId, DateTime startDate, DateTime endDate) async {
    Database db = await database;
    DateTime startOfDay = DateTime(startDate.year, startDate.month, startDate.day);
    DateTime endOfDay = DateTime(endDate.year, endDate.month, endDate.day, 23, 59, 59);

    List<Map<String, dynamic>> maps = await db.query(
      'fertility_data',
      where: 'user_id = ? AND date >= ? AND date <= ?',
      whereArgs: [
        userId,
        startOfDay.millisecondsSinceEpoch,
        endOfDay.millisecondsSinceEpoch,
      ],
    );

    return List.generate(maps.length, (i) {
      return FertilityData.fromMap(maps[i]);
    });
  }

  Future<int> updateFertilityData(FertilityData fertilityData) async {
    Database db = await database;
    return await db.update(
      'fertility_data',
      fertilityData.toMap(),
      where: 'id = ?',
      whereArgs: [fertilityData.id],
    );
  }
}
