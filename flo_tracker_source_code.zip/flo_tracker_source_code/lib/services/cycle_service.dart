import 'package:flo_tracker/models/cycle.dart';
import 'package:flo_tracker/services/database_helper.dart';
import 'package:flo_tracker/services/auth_service.dart';
import 'dart:async';

class CycleService {
  final DatabaseHelper _databaseHelper;
  final AuthService _authService;
  
  // Singleton pattern
  static final CycleService _instance = CycleService._internal();
  factory CycleService() => _instance;
  
  CycleService._internal() 
    : _databaseHelper = DatabaseHelper(),
      _authService = AuthService();
  
  // Stream to broadcast cycle data changes
  final _cycleDataController = StreamController<List<Cycle>>.broadcast();
  Stream<List<Cycle>> get cycleDataChanges => _cycleDataController.stream;
  
  // Error message
  String? _errorMessage;
  String? get errorMessage => _errorMessage;
  
  // Loading state
  bool _isLoading = false;
  bool get isLoading => _isLoading;
  
  // Cycle data
  List<Cycle> _cycles = [];
  List<Cycle> get cycles => _cycles;
  
  Cycle? _currentCycle;
  Cycle? get currentCycle => _currentCycle;
  
  List<Cycle> _predictions = [];
  List<Cycle> get predictions => _predictions;
  
  // Initialize cycle service
  Future<void> initialize() async {
    if (_authService.currentUser == null) {
      _setErrorMessage('No user logged in');
      return;
    }
    
    _setLoading(true);
    
    try {
      await _loadCycleData();
      await _generatePredictions();
      _setLoading(false);
    } catch (e) {
      _setErrorMessage('Failed to initialize cycle data: ${e.toString()}');
      _setLoading(false);
    }
  }
  
  // Log period start
  Future<bool> logPeriodStart(DateTime startDate, {String? notes}) async {
    if (_authService.currentUser == null) {
      _setErrorMessage('No user logged in');
      return false;
    }
    
    try {
      final cycle = Cycle(
        userId: _authService.currentUser!.id,
        startDate: startDate,
        notes: notes,
      );
      
      await _databaseHelper.insertCycle(cycle);
      
      // Reload cycle data
      await _loadCycleData();
      await _generatePredictions();
      
      return true;
    } catch (e) {
      _setErrorMessage('Failed to log period start: ${e.toString()}');
      return false;
    }
  }
  
  // Log period end
  Future<bool> logPeriodEnd(String cycleId, DateTime endDate, {String? notes}) async {
    if (_authService.currentUser == null) {
      _setErrorMessage('No user logged in');
      return false;
    }
    
    try {
      // Find the cycle
      final cycleIndex = _cycles.indexWhere((c) => c.id == cycleId);
      if (cycleIndex == -1) {
        _setErrorMessage('Cycle not found');
        return false;
      }
      
      final cycle = _cycles[cycleIndex];
      
      // Validate end date
      if (endDate.isBefore(cycle.startDate)) {
        _setErrorMessage('End date cannot be before start date');
        return false;
      }
      
      // Update cycle
      final updatedCycle = cycle.copyWith(
        endDate: endDate,
        notes: notes ?? cycle.notes,
      );
      
      await _databaseHelper.updateCycle(updatedCycle);
      
      // Reload cycle data
      await _loadCycleData();
      await _generatePredictions();
      
      return true;
    } catch (e) {
      _setErrorMessage('Failed to log period end: ${e.toString()}');
      return false;
    }
  }
  
  // Check if today is a period day
  bool get isTodayPeriodDay {
    if (_currentCycle == null) {
      return false;
    }
    
    final today = DateTime.now();
    final normalizedToday = DateTime(today.year, today.month, today.day);
    final normalizedStartDate = DateTime(
      _currentCycle!.startDate.year,
      _currentCycle!.startDate.month,
      _currentCycle!.startDate.day,
    );
    
    // If cycle has an end date, check if today is between start and end
    if (_currentCycle!.endDate != null) {
      final normalizedEndDate = DateTime(
        _currentCycle!.endDate!.year,
        _currentCycle!.endDate!.month,
        _currentCycle!.endDate!.day,
      );
      
      return !normalizedToday.isBefore(normalizedStartDate) && 
             !normalizedToday.isAfter(normalizedEndDate);
    }
    
    // If no end date, check if today is within the expected period length
    final periodLength = _authService.currentUser?.periodLength ?? 5;
    final periodEndDate = normalizedStartDate.add(Duration(days: periodLength - 1));
    
    return !normalizedToday.isBefore(normalizedStartDate) && 
           !normalizedToday.isAfter(periodEndDate);
  }
  
  // Calculate days until next period
  int get daysUntilNextPeriod {
    if (_predictions.isEmpty) {
      return 28; // Default cycle length
    }
    
    final today = DateTime.now();
    final normalizedToday = DateTime(today.year, today.month, today.day);
    
    // Find the next predicted period
    for (final prediction in _predictions) {
      final normalizedStartDate = DateTime(
        prediction.startDate.year,
        prediction.startDate.month,
        prediction.startDate.day,
      );
      
      if (!normalizedStartDate.isBefore(normalizedToday)) {
        return normalizedStartDate.difference(normalizedToday).inDays;
      }
    }
    
    // If no prediction found, use the cycle length
    return _authService.currentUser?.cycleLength ?? 28;
  }
  
  // Helper methods
  Future<void> _loadCycleData() async {
    if (_authService.currentUser == null) {
      return;
    }
    
    // Load user cycles
    _cycles = await _databaseHelper.getUserCycles(_authService.currentUser!.id);
    
    // Load current cycle
    _currentCycle = await _databaseHelper.getCurrentCycle(_authService.currentUser!.id);
    
    // Load predictions
    _predictions = await _databaseHelper.getUserCyclePredictions(_authService.currentUser!.id);
    
    // Notify listeners
    _cycleDataController.add(_cycles);
  }
  
  Future<void> _generatePredictions() async {
    if (_authService.currentUser == null || _cycles.isEmpty) {
      return;
    }
    
    // Clear existing predictions
    final db = await _databaseHelper.database;
    await db.delete(
      'cycles',
      where: 'user_id = ? AND is_prediction = 1',
      whereArgs: [_authService.currentUser!.id],
    );
    
    // Sort cycles by start date
    _cycles.sort((a, b) => a.startDate.compareTo(b.startDate));
    
    // Calculate average cycle length
    int totalDays = 0;
    int cycleCount = 0;
    
    for (int i = 1; i < _cycles.length; i++) {
      final currentCycle = _cycles[i];
      final previousCycle = _cycles[i - 1];
      
      final daysBetween = currentCycle.startDate.difference(previousCycle.startDate).inDays;
      
      if (daysBetween > 0 && daysBetween < 60) { // Ignore outliers
        totalDays += daysBetween;
        cycleCount++;
      }
    }
    
    final averageCycleLength = cycleCount > 0 
        ? (totalDays / cycleCount).round() 
        : _authService.currentUser!.cycleLength;
    
    // Calculate average period length
    int totalPeriodDays = 0;
    int periodCount = 0;
    
    for (final cycle in _cycles) {
      if (cycle.endDate != null) {
        final periodLength = cycle.endDate!.difference(cycle.startDate).inDays + 1;
        
        if (periodLength > 0 && periodLength < 15) { // Ignore outliers
          totalPeriodDays += periodLength;
          periodCount++;
        }
      }
    }
    
    final averagePeriodLength = periodCount > 0 
        ? (totalPeriodDays / periodCount).round() 
        : _authService.currentUser!.periodLength;
    
    // Generate predictions for the next 3 cycles
    final lastCycle = _cycles.last;
    DateTime nextStartDate = lastCycle.startDate.add(Duration(days: averageCycleLength));
    
    // If the last cycle has an end date, use it as the reference
    if (lastCycle.endDate != null) {
      final lastPeriodLength = lastCycle.endDate!.difference(lastCycle.startDate).inDays + 1;
      nextStartDate = lastCycle.startDate.add(Duration(days: averageCycleLength));
    }
    
    // Generate 3 predictions
    for (int i = 0; i < 3; i++) {
      final predictionStartDate = nextStartDate.add(Duration(days: i * averageCycleLength));
      final predictionEndDate = predictionStartDate.add(Duration(days: averagePeriodLength - 1));
      
      final prediction = Cycle(
        userId: _authService.currentUser!.id,
        startDate: predictionStartDate,
        endDate: predictionEndDate,
        isPrediction: true,
      );
      
      await _databaseHelper.insertCycle(prediction);
      _predictions.add(prediction);
    }
  }
  
  void _setLoading(bool loading) {
    _isLoading = loading;
  }
  
  void _setErrorMessage(String? message) {
    _errorMessage = message;
  }
  
  void clearError() {
    _errorMessage = null;
  }
  
  // Dispose
  void dispose() {
    _cycleDataController.close();
  }
}
