import 'package:flutter/material.dart';
import 'package:flo_tracker/config/theme.dart';
import 'package:flo_tracker/config/routes.dart';
import 'package:provider/provider.dart';
import 'package:flo_tracker/viewmodels/auth_viewmodel.dart';
import 'package:flo_tracker/viewmodels/theme_viewmodel.dart';

class App extends StatelessWidget {
  const App({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Consumer2<ThemeViewModel, AuthViewModel>(
      builder: (context, themeViewModel, authViewModel, _) {
        return MaterialApp(
          title: 'Flo Tracker',
          theme: AppTheme.lightTheme,
          darkTheme: AppTheme.darkTheme,
          themeMode: themeViewModel.themeMode,
          initialRoute: _getInitialRoute(authViewModel),
          routes: Routes.getRoutes(),
          debugShowCheckedModeBanner: false,
        );
      },
    );
  }

  String _getInitialRoute(AuthViewModel authViewModel) {
    switch (authViewModel.status) {
      case AuthStatus.authenticated:
        return Routes.home;
      case AuthStatus.unauthenticated:
        return Routes.welcome;
      default:
        return Routes.splash;
    }
  }
}
