import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flo_tracker/config/theme.dart';

class AppStoreMetadata {
  // App Store (iOS) Metadata
  static const String appStoreAppName = "Flo Tracker";
  static const String appStoreSubtitle = "Period & Ovulation Tracker";
  static const String appStoreDescription = """
Flo Tracker is a comprehensive period tracking and ovulation prediction app designed to help you understand your menstrual cycle and reproductive health.

KEY FEATURES:
• Period Tracking: Log your period days and track cycle length
• Cycle Predictions: Get accurate predictions for your next period
• Symptom Logging: Track 70+ symptoms throughout your cycle
• Fertility Tracking: Identify your fertile window and ovulation day
• Insights & Reports: View personalized insights about your cycle patterns
• Partner Sharing: Share cycle information with your partner
• Privacy Protection: Keep your data secure with encryption and anonymous mode
• Customizable Reminders: Never miss tracking important cycle events

Whether you're tracking your period, trying to conceive, or simply want to understand your body better, Flo Tracker provides the tools and insights you need for your reproductive health journey.

Download Flo Tracker today and take control of your cycle!
""";

  static const List<String> appStoreKeywords = [
    "period tracker",
    "ovulation",
    "menstrual cycle",
    "fertility",
    "women's health",
    "pregnancy",
    "period calendar",
    "cycle tracker",
    "period diary",
    "menstruation",
    "period prediction",
    "ovulation calculator",
    "fertility tracker",
    "period reminder",
    "menstrual health"
  ];

  static const String appStorePrivacyPolicyUrl = "https://example.com/privacy-policy";
  static const String appStoreMarketingUrl = "https://example.com/flo-tracker";
  static const String appStoreSupportUrl = "https://example.com/support";

  // Google Play Store (Android) Metadata
  static const String playStoreAppName = "Flo Tracker - Period & Ovulation";
  static const String playStoreShortDescription = "Track your period, ovulation & fertility with this comprehensive cycle tracker";
  static const String playStoreFullDescription = """
Flo Tracker is a comprehensive period tracking and ovulation prediction app designed to help you understand your menstrual cycle and reproductive health.

TRACK YOUR PERIOD
• Log your period days and symptoms
• Get accurate predictions for your next period
• Receive notifications before your period starts
• Track cycle length and period duration

MONITOR YOUR FERTILITY
• Identify your fertile window and ovulation day
• Track basal body temperature and cervical mucus
• Log ovulation test results
• Get insights for family planning

LOG YOUR SYMPTOMS
• Track 70+ symptoms throughout your cycle
• Monitor mood, pain, discharge, and more
• Identify patterns in your symptoms
• Get personalized insights about your health

SHARE WITH PARTNER
• Share cycle information with your partner
• Help them understand your cycle phases
• Improve communication about fertility and intimacy

PRIVACY PROTECTION
• Keep your data secure with encryption
• Use anonymous mode for extra privacy
• Control what data is stored and shared

PERSONALIZED INSIGHTS
• View cycle statistics and trends
• Get health insights based on your data
• Learn about your unique cycle patterns

Whether you're tracking your period, trying to conceive, or simply want to understand your body better, Flo Tracker provides the tools and insights you need for your reproductive health journey.

Download Flo Tracker today and take control of your cycle!
""";

  static const List<String> playStoreKeywords = [
    "period tracker",
    "ovulation calculator",
    "menstrual cycle",
    "fertility tracker",
    "women's health",
    "pregnancy planner",
    "period calendar",
    "cycle tracker",
    "period diary",
    "menstruation",
    "period prediction",
    "ovulation tracking",
    "fertility window",
    "period reminder",
    "menstrual health"
  ];

  static const String playStorePrivacyPolicyUrl = "https://example.com/privacy-policy";
  static const String playStoreSupportUrl = "https://example.com/support";
  static const String playStoreWebsiteUrl = "https://example.com/flo-tracker";

  // App Category
  static const String appCategory = "Health & Fitness";
  
  // Content Rating
  static const String contentRating = "12+";
  
  // App Version
  static const String appVersion = "1.0.0";
  static const int buildNumber = 1;
}
