import 'package:flutter/material.dart';
import 'package:flo_tracker/ui/screens/splash_screen.dart';
import 'package:flo_tracker/ui/screens/welcome_screen.dart';
import 'package:flo_tracker/ui/screens/login_screen.dart';
import 'package:flo_tracker/ui/screens/register_screen.dart';
import 'package:flo_tracker/ui/screens/onboarding_screen.dart';
import 'package:flo_tracker/ui/screens/home_screen.dart';
import 'package:flo_tracker/ui/screens/day_detail_screen.dart';
import 'package:flo_tracker/ui/screens/symptom_log_screen.dart';
import 'package:flo_tracker/ui/screens/fertility_log_screen.dart';

class Routes {
  static const String splash = '/';
  static const String welcome = '/welcome';
  static const String login = '/login';
  static const String register = '/register';
  static const String onboarding = '/onboarding';
  static const String home = '/home';
  static const String dayDetail = '/day-detail';
  static const String symptomLog = '/symptom-log';
  static const String fertilityLog = '/fertility-log';

  static Map<String, WidgetBuilder> getRoutes() {
    return {
      splash: (context) => const SplashScreen(),
      welcome: (context) => const WelcomeScreen(),
      login: (context) => const LoginScreen(),
      register: (context) => const RegisterScreen(),
      onboarding: (context) => const OnboardingScreen(),
      home: (context) => const HomeScreen(),
      dayDetail: (context) {
        final args = ModalRoute.of(context)!.settings.arguments as DayDetailArguments;
        return DayDetailScreen(date: args.date);
      },
      symptomLog: (context) {
        final args = ModalRoute.of(context)?.settings.arguments as Map<String, dynamic>?;
        return SymptomLogScreen(date: args?['date']);
      },
      fertilityLog: (context) {
        final args = ModalRoute.of(context)?.settings.arguments as Map<String, dynamic>?;
        return FertilityLogScreen(date: args?['date']);
      },
    };
  }
}

class DayDetailArguments {
  final DateTime date;

  DayDetailArguments({required this.date});
}
