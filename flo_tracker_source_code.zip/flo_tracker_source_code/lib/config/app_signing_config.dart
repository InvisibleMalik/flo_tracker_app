import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class AppSigningConfig {
  // Android Signing Configuration
  static const String androidKeyAlias = "flo_tracker_key";
  static const String androidKeyPassword = "your_key_password_here"; // Replace in production
  static const String androidStorePassword = "your_store_password_here"; // Replace in production
  
  // iOS Signing Configuration
  static const String iosBundleIdentifier = "com.example.floTracker";
  static const String iosTeamId = "YOUR_TEAM_ID"; // Replace with actual Apple Developer Team ID
  
  // App Capabilities
  static const List<String> requiredPermissions = [
    "android.permission.INTERNET",
    "android.permission.ACCESS_NETWORK_STATE",
    "android.permission.VIBRATE",
    "android.permission.RECEIVE_BOOT_COMPLETED",
  ];
  
  // Firebase Configuration
  static const bool useFirebaseAnalytics = true;
  static const bool useFirebaseCrashlytics = true;
  static const bool useFirebasePerformance = false;
  
  // In-App Purchase Configuration
  static const bool enableInAppPurchases = true;
  static const String premiumSubscriptionId = "com.example.flotracker.premium_monthly";
  
  // App Center Configuration (for distribution)
  static const String appCenterAndroidAppSecret = "your_app_center_android_secret"; // Replace in production
  static const String appCenterIosAppSecret = "your_app_center_ios_secret"; // Replace in production
  
  // Generate keystore command for reference
  static String getKeystoreGenerationCommand() {
    return """
    keytool -genkey -v -keystore flo_tracker.keystore -alias $androidKeyAlias -keyalg RSA -keysize 2048 -validity 10000
    """;
  }
  
  // Instructions for iOS certificate setup
  static String getIosCertificateInstructions() {
    return """
    1. Log in to Apple Developer account
    2. Go to Certificates, IDs & Profiles
    3. Create a new App ID with bundle identifier: $iosBundleIdentifier
    4. Create a Distribution Certificate
    5. Create a Provisioning Profile for App Store distribution
    """;
  }
}
