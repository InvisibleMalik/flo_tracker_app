# App Store Submission Guide for Flo Tracker

This document provides instructions for finalizing and submitting the Flo Tracker app to both the Apple App Store and Google Play Store.

## Prerequisites

- Apple Developer Account ($99/year)
- Google Play Developer Account ($25 one-time fee)
- Completed app with all assets and configurations

## Android Submission Process

### 1. Generate a Signed APK/App Bundle

```bash
# Navigate to your project directory
cd ~/flo_tracker

# Create a keystore file if you don't have one
keytool -genkey -v -keystore flo_tracker.keystore -alias flo_tracker_key -keyalg RSA -keysize 2048 -validity 10000

# Create a key.properties file in the android/ folder with your keystore details
echo "storePassword=your_store_password_here
keyPassword=your_key_password_here
keyAlias=flo_tracker_key
storeFile=/path/to/flo_tracker.keystore" > android/key.properties

# Build the app bundle
flutter build appbundle
```

The app bundle will be created at `~/flo_tracker/build/app/outputs/bundle/release/app-release.aab`

### 2. Google Play Console Submission

1. Log in to the [Google Play Console](https://play.google.com/console)
2. Create a new app
3. Fill in the app details using the metadata from `app_store_metadata.dart`
4. Upload the app bundle (.aab file)
5. Add store listing details:
   - App name: "Flo Tracker - Period & Ovulation"
   - Short description (80 characters max)
   - Full description (4000 characters max)
   - Upload screenshots (at least 2)
   - Upload feature graphic (1024 x 500 px)
   - Upload app icon (512 x 512 px)
6. Set up content rating by completing the questionnaire
7. Set pricing and distribution (free with in-app purchases)
8. Review and publish to production or create a closed testing track

## iOS Submission Process

### 1. Configure iOS Signing

```bash
# Navigate to your project directory
cd ~/flo_tracker

# Open the iOS project in Xcode
open ios/Runner.xcworkspace
```

In Xcode:
1. Select the Runner project in the navigator
2. Select the Runner target
3. Go to the Signing & Capabilities tab
4. Select your team and ensure automatic signing is enabled
5. Update the Bundle Identifier to match your configuration

### 2. Build the iOS App

```bash
# Build the iOS app archive
flutter build ipa
```

The IPA file will be created at `~/flo_tracker/build/ios/archive/Runner.xcarchive`

### 3. App Store Connect Submission

1. Log in to [App Store Connect](https://appstoreconnect.apple.com/)
2. Create a new app
3. Fill in the app details using the metadata from `app_store_metadata.dart`
4. Use Xcode to upload the archive:
   - Open Xcode
   - Go to Window > Organizer
   - Select your archive
   - Click "Distribute App"
   - Follow the prompts to upload to App Store Connect
5. In App Store Connect, add:
   - App name: "Flo Tracker"
   - Subtitle: "Period & Ovulation Tracker"
   - Description
   - Keywords
   - Support URL
   - Marketing URL
   - Privacy Policy URL
   - Screenshots (at least 1 per device type)
   - App icon (1024 x 1024 px)
6. Set up pricing and availability
7. Submit for review

## App Screenshots

You'll need to create screenshots for various device sizes:

### iOS Screenshots
- iPhone 6.5" Display (1242 x 2688 px)
- iPhone 5.5" Display (1242 x 2208 px)
- iPad Pro 12.9" Display (2048 x 2732 px)

### Android Screenshots
- Phone (1080 x 1920 px)
- 7-inch tablet (1080 x 1920 px)
- 10-inch tablet (1080 x 1920 px)

## App Preview Videos (Optional)

You can also create app preview videos:

### iOS App Preview
- 15-30 seconds long
- Device-specific resolutions
- No people interacting with the device

### Android Promo Video
- Up to 2 minutes
- YouTube URL
- Show app features and benefits

## Final Checklist Before Submission

- [ ] App icon and splash screen display correctly
- [ ] All screens and features work as expected
- [ ] App handles network connectivity changes
- [ ] In-app purchases are configured correctly
- [ ] Privacy policy is accessible
- [ ] Terms of service are accessible
- [ ] App complies with platform-specific guidelines
- [ ] All required metadata is prepared
- [ ] Screenshots are created for all required device sizes
- [ ] App has been tested on multiple device sizes

## Post-Submission

After submission:
1. Monitor the review status in the respective developer consoles
2. Be prepared to address any issues raised by the review team
3. Once approved, the app will be available for download in the respective stores

## Updating the App

For future updates:
1. Increment the version number in `pubspec.yaml`
2. Make your changes
3. Follow the same build and submission process
4. Include release notes describing the changes
