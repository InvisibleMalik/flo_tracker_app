# Navigation Flow for Flo Tracker App

## Overview
This document outlines the navigation structure and user flow for the Flo Tracker application. The navigation is designed to provide intuitive access to all core features while maintaining a clean and user-friendly interface.

## App Structure

### Main Navigation
The app uses a bottom tab navigation with 5 primary sections:

1. **Home/Calendar** - Main tracking view with calendar and daily insights
2. **Insights** - Health insights, predictions, and patterns
3. **Log** - Quick access to symptom logging
4. **Articles** - Educational content and resources
5. **Profile** - User settings and account management

## Detailed Navigation Flow

### Authentication Flow
```
Splash Screen
├── Welcome Screen
│   ├── Login
│   │   └── Home Screen
│   ├── Register
│   │   └── Onboarding Flow
│   │       └── Home Screen
│   └── Continue as Anonymous
│       └── Limited Onboarding Flow
│           └── Home Screen (Anonymous Mode)
```

### Onboarding Flow
```
Onboarding Screen 1: Basic Information
├── Date of Birth
├── Last Period Start Date
├── Average Cycle Length
└── Continue to Screen 2

Onboarding Screen 2: Tracking Goals
├── Period Tracking
├── Fertility Tracking
├── Trying to Conceive
├── Pregnancy Tracking
└── Continue to Screen 3

Onboarding Screen 3: Notification Preferences
├── Period Reminders
├── Fertility Window Alerts
├── Daily Logging Reminders
└── Complete Onboarding
```

### Main App Flow

#### Home/Calendar Tab
```
Home Screen
├── Month View Calendar
│   └── Day Cell
│       └── Day Detail View
│           ├── Logged Symptoms
│           ├── Notes
│           └── Add/Edit Symptoms
├── Cycle Phase Indicator
├── Days Until Next Period/Ovulation
├── Quick Actions
│   ├── Log Period Start
│   ├── Log Period End
│   └── Log Symptoms
└── Today's Insights
    └── Insight Detail View
```

#### Insights Tab
```
Insights Screen
├── Cycle Statistics
│   └── Detailed Cycle History
├── Symptom Patterns
│   └── Symptom Pattern Detail
├── Fertility Predictions
│   └── Fertility Calendar View
└── Health Insights
    └── Insight Detail View
```

#### Log Tab
```
Log Screen
├── Quick Log Today's Symptoms
│   ├── Mood Category
│   ├── Pain Category
│   ├── Discharge Category
│   ├── Sexual Activity Category
│   └── Other Categories
├── Log Period
│   ├── Start Period
│   └── End Period
├── Log Fertility Data
│   ├── Basal Body Temperature
│   ├── Cervical Mucus
│   └── Ovulation Test Results
└── View Recent Logs
    └── Edit Previous Logs
```

#### Articles Tab
```
Articles Screen
├── Featured Articles
├── Categories
│   ├── Period Health
│   ├── Fertility
│   ├── Sexual Health
│   ├── Pregnancy
│   └── General Wellness
├── Bookmarked Articles
└── Article Detail View
    ├── Share Article
    └── Bookmark Article
```

#### Profile Tab
```
Profile Screen
├── Account Settings
│   ├── Personal Information
│   ├── Change Password
│   └── Email Preferences
├── App Settings
│   ├── Notifications
│   ├── Theme
│   └── Language
├── Tracking Preferences
│   ├── Cycle Settings
│   ├── Symptoms to Track
│   └── Birth Control Method
├── Partner Sharing
│   ├── Create Share Code
│   ├── Manage Sharing Permissions
│   └── View Partner Activity
├── Privacy
│   ├── Toggle Anonymous Mode
│   ├── Data Export
│   └── Account Deletion
├── Premium Subscription
│   ├── View Benefits
│   ├── Manage Subscription
│   └── Enter Promo Code
└── Help & Support
    ├── FAQ
    ├── Contact Support
    └── About
```

### Feature-Specific Flows

#### Partner Sharing Flow
```
Partner Sharing Screen
├── Not Sharing
│   └── Create Share Code
│       └── Share Code Display
│           └── Sharing Active Screen
├── Sharing Active
│   ├── Manage Permissions
│   │   ├── Share Cycles
│   │   ├── Share Symptoms
│   │   └── Share Fertility
│   ├── View Partner Activity
│   └── Deactivate Sharing
└── Join as Partner
    ├── Enter Share Code
    └── Partner View
        └── View Shared Data
```

#### Premium Subscription Flow
```
Premium Screen
├── Free Features
├── Premium Features
├── Subscription Plans
│   ├── Monthly Plan
│   ├── Annual Plan
│   └── Payment Processing
└── Restore Purchase
```

## Modal Overlays

### Quick Log Modal
Accessible from multiple points in the app for quick symptom logging without navigating away from the current screen.

### Period Start/End Modal
Quick access to log period start or end dates.

### Notification Modals
Important alerts and reminders that appear based on user preferences and predicted events.

## Gestures and Interactions

- **Swipe Left/Right** on Calendar: Navigate between months
- **Tap and Hold** on Calendar Day: Quick preview of day's data
- **Pull to Refresh**: Update data on most screens
- **Swipe to Dismiss**: Notifications and certain modals
- **Double Tap**: Zoom in on charts and graphs

## Accessibility Considerations

- All navigation elements are labeled for screen readers
- Critical paths have multiple access methods (tab navigation, gestures, buttons)
- Color is not the sole indicator for important information
- Text size adjusts based on system settings
- Voice commands for common actions

## Responsive Behavior

- Portrait orientation optimized for phone use
- Landscape orientation supported with adjusted layouts
- Tablet-specific layouts with split views for larger screens
- Web version maintains consistent navigation patterns while optimizing for desktop use
