# Database Schema for Flo Tracker App

## Overview
This document outlines the database schema for the Flo Tracker application. The schema is designed to support all core features including period tracking, symptom logging, fertility tracking, partner sharing, and premium features.

## Database Tables

### Users
Stores user account information and preferences.

```
Table: users
- id (UUID, primary key)
- email (String, nullable) - Can be null for anonymous users
- password_hash (String, nullable) - Hashed password, null for anonymous or social login
- display_name (String)
- date_of_birth (Date)
- created_at (Timestamp)
- last_login (Timestamp)
- is_premium (Boolean) - Whether user has premium subscription
- premium_expiry (Timestamp, nullable)
- anonymous_id (String, nullable) - Identifier for anonymous mode
- is_anonymous_mode (Boolean) - Whether user is in anonymous mode
- notification_settings (JSON) - User notification preferences
- theme_preference (String) - UI theme preference
- language (String) - Preferred language
- timezone (String) - User's timezone for accurate predictions
```

### Cycles
Stores menstrual cycle information.

```
Table: cycles
- id (UUID, primary key)
- user_id (UUID, foreign key to users.id)
- start_date (Date) - First day of period
- end_date (Date, nullable) - Last day of period (can be predicted)
- cycle_length (Integer, nullable) - Length of entire cycle in days
- period_length (Integer, nullable) - Length of period in days
- is_predicted (Boolean) - Whether this cycle is predicted or actual
- notes (Text, nullable) - User notes about this cycle
- created_at (Timestamp)
- updated_at (Timestamp)
```

### Symptoms
Master list of trackable symptoms.

```
Table: symptoms
- id (UUID, primary key)
- category (String) - e.g., "Mood", "Pain", "Discharge", etc.
- name (String) - Symptom name
- icon (String) - Icon identifier
- description (Text, nullable)
- is_premium (Boolean) - Whether tracking this symptom requires premium
```

### UserSymptoms
Records symptoms logged by users.

```
Table: user_symptoms
- id (UUID, primary key)
- user_id (UUID, foreign key to users.id)
- symptom_id (UUID, foreign key to symptoms.id)
- date (Date) - Date when symptom was experienced
- intensity (Integer, nullable) - Intensity level (1-5)
- notes (Text, nullable) - Additional notes
- created_at (Timestamp)
- updated_at (Timestamp)
```

### FertilityData
Stores fertility-related information.

```
Table: fertility_data
- id (UUID, primary key)
- user_id (UUID, foreign key to users.id)
- date (Date)
- basal_body_temperature (Decimal, nullable)
- cervical_mucus_type (String, nullable)
- ovulation_test_result (String, nullable) - e.g., "positive", "negative", "invalid"
- is_fertile_day (Boolean)
- is_ovulation_day (Boolean)
- fertility_score (Integer, nullable) - Calculated fertility score (1-10)
- created_at (Timestamp)
- updated_at (Timestamp)
```

### PartnerSharing
Manages partner sharing functionality.

```
Table: partner_sharing
- id (UUID, primary key)
- user_id (UUID, foreign key to users.id)
- partner_email (String, nullable)
- partner_id (UUID, nullable, foreign key to users.id)
- share_code (String) - Unique code for partner to join
- is_active (Boolean)
- share_cycles (Boolean) - Whether to share cycle information
- share_symptoms (Boolean) - Whether to share symptom information
- share_fertility (Boolean) - Whether to share fertility information
- created_at (Timestamp)
- updated_at (Timestamp)
```

### HealthInsights
Stores personalized insights and predictions.

```
Table: health_insights
- id (UUID, primary key)
- user_id (UUID, foreign key to users.id)
- insight_type (String) - e.g., "period_prediction", "symptom_pattern", "fertility_window"
- title (String)
- description (Text)
- start_date (Date, nullable)
- end_date (Date, nullable)
- is_read (Boolean)
- is_premium (Boolean) - Whether this insight is premium-only
- created_at (Timestamp)
```

### UserSettings
Stores additional user settings and preferences.

```
Table: user_settings
- id (UUID, primary key)
- user_id (UUID, foreign key to users.id)
- average_cycle_length (Integer, nullable)
- average_period_length (Integer, nullable)
- birth_control_method (String, nullable)
- pregnancy_mode (Boolean) - Whether user is in pregnancy tracking mode
- pregnancy_start_date (Date, nullable)
- trying_to_conceive (Boolean)
- created_at (Timestamp)
- updated_at (Timestamp)
```

### Articles
Educational content for users.

```
Table: articles
- id (UUID, primary key)
- title (String)
- content (Text)
- category (String) - e.g., "Period", "Fertility", "Pregnancy"
- tags (Array of Strings)
- author (String)
- is_premium (Boolean) - Whether article is premium-only
- published_at (Timestamp)
- updated_at (Timestamp)
```

### UserArticleInteractions
Tracks user interactions with articles.

```
Table: user_article_interactions
- id (UUID, primary key)
- user_id (UUID, foreign key to users.id)
- article_id (UUID, foreign key to articles.id)
- is_read (Boolean)
- is_bookmarked (Boolean)
- read_at (Timestamp, nullable)
```

## Relationships

1. A User has many Cycles
2. A User has many UserSymptoms
3. A User has one UserSettings
4. A User has many FertilityData entries
5. A User has many HealthInsights
6. A User can have one active PartnerSharing
7. A Symptom can be logged by many Users (through UserSymptoms)
8. An Article can be interacted with by many Users (through UserArticleInteractions)

## Data Security Considerations

1. Personal identifiable information (PII) should be encrypted at rest
2. Anonymous mode should ensure no PII is stored with health data
3. Partner sharing should be implemented with proper consent mechanisms
4. Data deletion requests should remove all user data across all tables
5. Premium content should be properly gated based on subscription status
