# Component Architecture for Flo Tracker App

## Overview
This document outlines the component architecture for the Flo Tracker application. The architecture follows Flutter's widget-based approach with a clean separation of concerns between UI components, business logic, and data access.

## Architecture Pattern
The app follows a modified Model-View-ViewModel (MVVM) architecture with the following layers:

1. **UI Layer** (View): Flutter widgets that render the user interface
2. **ViewModel Layer**: Manages UI state and business logic
3. **Repository Layer**: Abstracts data access and manipulation
4. **Service Layer**: Handles API communication and local storage
5. **Model Layer**: Data models representing domain entities

## Folder Structure

```
lib/
├── main.dart                  # App entry point
├── app.dart                   # App configuration and theme
├── config/                    # App configuration
│   ├── constants.dart         # App constants
│   ├── routes.dart            # Route definitions
│   └── theme.dart             # App theme configuration
├── models/                    # Data models
│   ├── user.dart
│   ├── cycle.dart
│   ├── symptom.dart
│   ├── fertility_data.dart
│   ├── article.dart
│   └── ...
├── repositories/              # Data repositories
│   ├── user_repository.dart
│   ├── cycle_repository.dart
│   ├── symptom_repository.dart
│   ├── fertility_repository.dart
│   └── ...
├── services/                  # API and storage services
│   ├── api/                   # API services
│   │   ├── api_client.dart
│   │   ├── auth_service.dart
│   │   ├── cycle_service.dart
│   │   └── ...
│   ├── storage/               # Local storage services
│   │   ├── secure_storage.dart
│   │   ├── database_helper.dart
│   │   └── ...
│   └── analytics/             # Analytics services
│       └── analytics_service.dart
├── viewmodels/                # ViewModels for state management
│   ├── auth_viewmodel.dart
│   ├── cycle_viewmodel.dart
│   ├── symptom_viewmodel.dart
│   ├── fertility_viewmodel.dart
│   └── ...
├── ui/                        # UI components
│   ├── screens/               # Full screens
│   │   ├── auth/              # Authentication screens
│   │   │   ├── login_screen.dart
│   │   │   ├── register_screen.dart
│   │   │   └── ...
│   │   ├── home/              # Home tab screens
│   │   │   ├── home_screen.dart
│   │   │   ├── calendar_view.dart
│   │   │   └── ...
│   │   ├── insights/          # Insights tab screens
│   │   ├── log/               # Log tab screens
│   │   ├── articles/          # Articles tab screens
│   │   └── profile/           # Profile tab screens
│   ├── widgets/               # Reusable widgets
│   │   ├── common/            # Common widgets
│   │   │   ├── app_bar.dart
│   │   │   ├── loading_indicator.dart
│   │   │   └── ...
│   │   ├── calendar/          # Calendar-related widgets
│   │   ├── symptoms/          # Symptom-related widgets
│   │   ├── fertility/         # Fertility-related widgets
│   │   └── ...
│   └── dialogs/               # Modal dialogs
│       ├── symptom_log_dialog.dart
│       ├── period_log_dialog.dart
│       └── ...
└── utils/                     # Utility functions
    ├── date_utils.dart
    ├── validators.dart
    ├── formatters.dart
    └── ...
```

## Core Components

### UI Components

#### Common Widgets
- **AppBar**: Customized app bar with consistent styling
- **BottomNavigation**: Tab-based navigation bar
- **LoadingIndicator**: Loading state indicator
- **ErrorDisplay**: Error message display
- **PremiumBadge**: Indicator for premium features
- **ActionButton**: Primary action button with consistent styling

#### Calendar Widgets
- **MonthCalendar**: Monthly calendar view
- **DayCell**: Individual day cell in calendar
- **CycleIndicator**: Visual indicator for cycle phases
- **PredictionMarker**: Visual marker for predicted events

#### Symptom Widgets
- **SymptomCategory**: Category grouping for symptoms
- **SymptomIcon**: Icon representation of symptoms
- **SymptomIntensity**: Intensity selector for symptoms
- **SymptomLogCard**: Card displaying logged symptoms

#### Fertility Widgets
- **FertilityCalendar**: Specialized calendar for fertility tracking
- **OvulationIndicator**: Visual indicator for ovulation
- **FertilityScore**: Visual representation of fertility score
- **TemperatureChart**: Chart for basal body temperature

#### Profile Widgets
- **SettingsItem**: Individual setting item
- **ToggleOption**: Toggle switch for boolean settings
- **SubscriptionCard**: Subscription plan display
- **PartnerShareCard**: Partner sharing information display

### ViewModels

- **AuthViewModel**: Manages authentication state and user information
- **CycleViewModel**: Manages cycle data and predictions
- **SymptomViewModel**: Manages symptom logging and retrieval
- **FertilityViewModel**: Manages fertility data and predictions
- **InsightsViewModel**: Manages health insights and statistics
- **ArticleViewModel**: Manages article content and interactions
- **PartnerViewModel**: Manages partner sharing functionality
- **SettingsViewModel**: Manages user settings and preferences
- **SubscriptionViewModel**: Manages premium subscription state

### Repositories

- **UserRepository**: User account and profile data
- **CycleRepository**: Menstrual cycle data
- **SymptomRepository**: Symptom logging and retrieval
- **FertilityRepository**: Fertility data and predictions
- **InsightRepository**: Health insights and statistics
- **ArticleRepository**: Educational content
- **PartnerRepository**: Partner sharing functionality
- **SettingsRepository**: User settings and preferences

### Services

#### API Services
- **ApiClient**: Base HTTP client for API communication
- **AuthService**: Authentication API endpoints
- **CycleService**: Cycle-related API endpoints
- **SymptomService**: Symptom-related API endpoints
- **FertilityService**: Fertility-related API endpoints
- **InsightService**: Health insights API endpoints
- **ArticleService**: Article content API endpoints
- **PartnerService**: Partner sharing API endpoints
- **SubscriptionService**: Subscription management API endpoints

#### Storage Services
- **SecureStorage**: Secure storage for sensitive data
- **DatabaseHelper**: Local database management
- **CacheManager**: Caching mechanism for API responses
- **PreferenceManager**: User preferences storage

## State Management

The app uses Provider pattern for state management with the following key providers:

- **AuthProvider**: Authentication state
- **UserProvider**: User profile data
- **CycleProvider**: Cycle tracking data
- **SymptomProvider**: Symptom logging data
- **FertilityProvider**: Fertility tracking data
- **ThemeProvider**: App theme settings
- **LanguageProvider**: App language settings
- **SubscriptionProvider**: Premium subscription state

## Navigation

Navigation is handled using Flutter's Navigator 2.0 with a custom router that supports:

- Deep linking
- Path-based routing
- Route guards for authenticated routes
- Transition animations

## Data Flow

1. User interacts with UI components
2. UI components call methods on ViewModels
3. ViewModels update state and call Repository methods
4. Repositories coordinate between API Services and Storage Services
5. Data flows back up the chain, updating UI through state changes

## Offline Support

The app implements offline support through:

- Local database caching of user data
- Optimistic UI updates
- Background synchronization when connectivity is restored
- Conflict resolution for data modified while offline

## Security Considerations

- Sensitive data is stored using secure storage
- API communication uses HTTPS with certificate pinning
- Authentication tokens are securely managed
- Personal data can be anonymized based on user preference

## Performance Optimizations

- Lazy loading of screen content
- Pagination for list data
- Image caching and optimization
- Minimizing rebuilds through efficient state management
- Background processing for intensive calculations

## Testing Strategy

- **Unit Tests**: For ViewModels, Repositories, and Services
- **Widget Tests**: For UI components
- **Integration Tests**: For feature flows
- **Golden Tests**: For UI appearance verification
- **Mocks**: For API and storage services during testing
