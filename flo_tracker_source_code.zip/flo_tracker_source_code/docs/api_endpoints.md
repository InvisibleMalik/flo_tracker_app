# API Endpoints for Flo Tracker App

## Overview
This document outlines the API endpoints for the Flo Tracker application. These endpoints support all core features including user authentication, period tracking, symptom logging, fertility tracking, partner sharing, and premium features.

## Base URL
`https://api.flotracker.app/v1`

## Authentication
All endpoints except for registration and login require authentication using JWT tokens.

### Headers
```
Authorization: Bearer {jwt_token}
```

## Endpoints

### Authentication

#### Register User
```
POST /auth/register
```
Request Body:
```json
{
  "email": "user@example.com",
  "password": "securepassword",
  "display_name": "Jane Doe",
  "date_of_birth": "1990-01-01",
  "timezone": "America/New_York"
}
```
Response:
```json
{
  "user_id": "uuid",
  "token": "jwt_token",
  "expires_at": "timestamp"
}
```

#### Login
```
POST /auth/login
```
Request Body:
```json
{
  "email": "user@example.com",
  "password": "securepassword"
}
```
Response:
```json
{
  "user_id": "uuid",
  "token": "jwt_token",
  "expires_at": "timestamp"
}
```

#### Create Anonymous User
```
POST /auth/anonymous
```
Response:
```json
{
  "anonymous_id": "uuid",
  "token": "jwt_token",
  "expires_at": "timestamp"
}
```

#### Convert Anonymous to Registered
```
POST /auth/convert
```
Request Body:
```json
{
  "anonymous_id": "uuid",
  "email": "user@example.com",
  "password": "securepassword",
  "display_name": "Jane Doe"
}
```
Response:
```json
{
  "user_id": "uuid",
  "token": "jwt_token",
  "expires_at": "timestamp"
}
```

### User Profile

#### Get User Profile
```
GET /users/profile
```
Response:
```json
{
  "id": "uuid",
  "email": "user@example.com",
  "display_name": "Jane Doe",
  "date_of_birth": "1990-01-01",
  "is_premium": false,
  "premium_expiry": null,
  "is_anonymous_mode": false,
  "notification_settings": {},
  "theme_preference": "light",
  "language": "en",
  "timezone": "America/New_York",
  "created_at": "timestamp"
}
```

#### Update User Profile
```
PUT /users/profile
```
Request Body:
```json
{
  "display_name": "Jane Smith",
  "theme_preference": "dark",
  "language": "es"
}
```
Response:
```json
{
  "id": "uuid",
  "email": "user@example.com",
  "display_name": "Jane Smith",
  "date_of_birth": "1990-01-01",
  "is_premium": false,
  "premium_expiry": null,
  "is_anonymous_mode": false,
  "notification_settings": {},
  "theme_preference": "dark",
  "language": "es",
  "timezone": "America/New_York",
  "created_at": "timestamp",
  "updated_at": "timestamp"
}
```

#### Toggle Anonymous Mode
```
POST /users/anonymous-mode
```
Request Body:
```json
{
  "is_anonymous_mode": true
}
```
Response:
```json
{
  "is_anonymous_mode": true,
  "anonymous_id": "uuid"
}
```

### Cycles

#### Get Cycles
```
GET /cycles?start_date=2025-01-01&end_date=2025-12-31
```
Response:
```json
{
  "cycles": [
    {
      "id": "uuid",
      "start_date": "2025-01-05",
      "end_date": "2025-01-10",
      "cycle_length": 28,
      "period_length": 5,
      "is_predicted": false,
      "notes": "Light flow this month"
    },
    {
      "id": "uuid",
      "start_date": "2025-02-02",
      "end_date": "2025-02-07",
      "cycle_length": 28,
      "period_length": 5,
      "is_predicted": false,
      "notes": null
    }
  ]
}
```

#### Log Period Start
```
POST /cycles
```
Request Body:
```json
{
  "start_date": "2025-03-01",
  "notes": "Started earlier than expected"
}
```
Response:
```json
{
  "id": "uuid",
  "start_date": "2025-03-01",
  "end_date": null,
  "cycle_length": null,
  "period_length": null,
  "is_predicted": false,
  "notes": "Started earlier than expected",
  "created_at": "timestamp"
}
```

#### Log Period End
```
PUT /cycles/{cycle_id}
```
Request Body:
```json
{
  "end_date": "2025-03-06",
  "notes": "Normal flow"
}
```
Response:
```json
{
  "id": "uuid",
  "start_date": "2025-03-01",
  "end_date": "2025-03-06",
  "cycle_length": 28,
  "period_length": 6,
  "is_predicted": false,
  "notes": "Normal flow",
  "updated_at": "timestamp"
}
```

#### Get Cycle Predictions
```
GET /cycles/predictions?months=3
```
Response:
```json
{
  "predictions": [
    {
      "id": "uuid",
      "start_date": "2025-03-29",
      "end_date": "2025-04-03",
      "cycle_length": 28,
      "period_length": 5,
      "is_predicted": true
    },
    {
      "id": "uuid",
      "start_date": "2025-04-26",
      "end_date": "2025-05-01",
      "cycle_length": 28,
      "period_length": 5,
      "is_predicted": true
    },
    {
      "id": "uuid",
      "start_date": "2025-05-24",
      "end_date": "2025-05-29",
      "cycle_length": 28,
      "period_length": 5,
      "is_predicted": true
    }
  ]
}
```

### Symptoms

#### Get Available Symptoms
```
GET /symptoms
```
Response:
```json
{
  "symptoms": [
    {
      "id": "uuid",
      "category": "Mood",
      "name": "Irritability",
      "icon": "mood_irritable",
      "description": "Feeling easily annoyed or provoked",
      "is_premium": false
    },
    {
      "id": "uuid",
      "category": "Pain",
      "name": "Cramps",
      "icon": "pain_cramps",
      "description": "Abdominal or pelvic pain",
      "is_premium": false
    }
  ]
}
```

#### Log Symptom
```
POST /symptoms/log
```
Request Body:
```json
{
  "symptom_id": "uuid",
  "date": "2025-03-02",
  "intensity": 3,
  "notes": "Moderate cramps in the morning"
}
```
Response:
```json
{
  "id": "uuid",
  "symptom_id": "uuid",
  "symptom_name": "Cramps",
  "date": "2025-03-02",
  "intensity": 3,
  "notes": "Moderate cramps in the morning",
  "created_at": "timestamp"
}
```

#### Get Logged Symptoms
```
GET /symptoms/log?start_date=2025-03-01&end_date=2025-03-31
```
Response:
```json
{
  "symptoms": [
    {
      "id": "uuid",
      "symptom_id": "uuid",
      "symptom_name": "Cramps",
      "category": "Pain",
      "date": "2025-03-02",
      "intensity": 3,
      "notes": "Moderate cramps in the morning"
    },
    {
      "id": "uuid",
      "symptom_id": "uuid",
      "symptom_name": "Irritability",
      "category": "Mood",
      "date": "2025-03-03",
      "intensity": 2,
      "notes": null
    }
  ]
}
```

#### Delete Logged Symptom
```
DELETE /symptoms/log/{log_id}
```
Response:
```
204 No Content
```

### Fertility

#### Get Fertility Data
```
GET /fertility?start_date=2025-03-01&end_date=2025-03-31
```
Response:
```json
{
  "fertility_data": [
    {
      "id": "uuid",
      "date": "2025-03-10",
      "basal_body_temperature": 36.7,
      "cervical_mucus_type": "creamy",
      "ovulation_test_result": "negative",
      "is_fertile_day": true,
      "is_ovulation_day": false,
      "fertility_score": 7
    },
    {
      "id": "uuid",
      "date": "2025-03-11",
      "basal_body_temperature": 36.9,
      "cervical_mucus_type": "egg-white",
      "ovulation_test_result": "positive",
      "is_fertile_day": true,
      "is_ovulation_day": true,
      "fertility_score": 10
    }
  ]
}
```

#### Log Fertility Data
```
POST /fertility
```
Request Body:
```json
{
  "date": "2025-03-12",
  "basal_body_temperature": 37.1,
  "cervical_mucus_type": "egg-white",
  "ovulation_test_result": "positive"
}
```
Response:
```json
{
  "id": "uuid",
  "date": "2025-03-12",
  "basal_body_temperature": 37.1,
  "cervical_mucus_type": "egg-white",
  "ovulation_test_result": "positive",
  "is_fertile_day": true,
  "is_ovulation_day": true,
  "fertility_score": 10,
  "created_at": "timestamp"
}
```

#### Get Fertility Predictions
```
GET /fertility/predictions?months=1
```
Response:
```json
{
  "predictions": [
    {
      "date": "2025-04-08",
      "is_fertile_day": true,
      "is_ovulation_day": false,
      "fertility_score": 7
    },
    {
      "date": "2025-04-09",
      "is_fertile_day": true,
      "is_ovulation_day": false,
      "fertility_score": 8
    },
    {
      "date": "2025-04-10",
      "is_fertile_day": true,
      "is_ovulation_day": true,
      "fertility_score": 10
    },
    {
      "date": "2025-04-11",
      "is_fertile_day": true,
      "is_ovulation_day": false,
      "fertility_score": 8
    },
    {
      "date": "2025-04-12",
      "is_fertile_day": true,
      "is_ovulation_day": false,
      "fertility_score": 7
    }
  ]
}
```

### Partner Sharing

#### Create Partner Share
```
POST /partner/share
```
Request Body:
```json
{
  "share_cycles": true,
  "share_symptoms": true,
  "share_fertility": false
}
```
Response:
```json
{
  "id": "uuid",
  "share_code": "ABC123XYZ",
  "share_cycles": true,
  "share_symptoms": true,
  "share_fertility": false,
  "is_active": true,
  "created_at": "timestamp"
}
```

#### Join as Partner
```
POST /partner/join
```
Request Body:
```json
{
  "share_code": "ABC123XYZ"
}
```
Response:
```json
{
  "partner_id": "uuid",
  "partner_name": "Jane Doe",
  "share_cycles": true,
  "share_symptoms": true,
  "share_fertility": false
}
```

#### Get Partner Data
```
GET /partner/data
```
Response:
```json
{
  "partner_name": "Jane Doe",
  "current_cycle": {
    "start_date": "2025-03-01",
    "end_date": "2025-03-06",
    "current_day": 5,
    "is_period": true
  },
  "recent_symptoms": [
    {
      "date": "2025-03-02",
      "symptom_name": "Cramps",
      "intensity": 3
    },
    {
      "date": "2025-03-03",
      "symptom_name": "Irritability",
      "intensity": 2
    }
  ],
  "next_period_prediction": "2025-03-29"
}
```

#### Update Partner Sharing Settings
```
PUT /partner/share
```
Request Body:
```json
{
  "share_cycles": true,
  "share_symptoms": false,
  "share_fertility": false
}
```
Response:
```json
{
  "id": "uuid",
  "share_code": "ABC123XYZ",
  "share_cycles": true,
  "share_symptoms": false,
  "share_fertility": false,
  "is_active": true,
  "updated_at": "timestamp"
}
```

#### Deactivate Partner Sharing
```
DELETE /partner/share
```
Response:
```
204 No Content
```

### Health Insights

#### Get Health Insights
```
GET /insights
```
Response:
```json
{
  "insights": [
    {
      "id": "uuid",
      "insight_type": "period_prediction",
      "title": "Your next period is in 5 days",
      "description": "Based on your cycle history, your next period is expected to start on March 29, 2025.",
      "start_date": "2025-03-29",
      "end_date": "2025-04-03",
      "is_read": false,
      "is_premium": false,
      "created_at": "timestamp"
    },
    {
      "id": "uuid",
      "insight_type": "symptom_pattern",
      "title": "Cramps pattern detected",
      "description": "You tend to experience cramps 1-2 days before your period starts.",
      "start_date": null,
      "end_date": null,
      "is_read": false,
      "is_premium": true,
      "created_at": "timestamp"
    }
  ]
}
```

#### Mark Insight as Read
```
PUT /insights/{insight_id}/read
```
Response:
```json
{
  "id": "uuid",
  "is_read": true,
  "updated_at": "timestamp"
}
```

### User Settings

#### Get User Settings
```
GET /users/settings
```
Response:
```json
{
  "average_cycle_length": 28,
  "average_period_length": 5,
  "birth_control_method": "none",
  "pregnancy_mode": false,
  "pregnancy_start_date": null,
  "trying_to_conceive": false
}
```

#### Update User Settings
```
PUT /users/settings
```
Request Body:
```json
{
  "birth_control_method": "pill",
  "trying_to_conceive": true
}
```
Response:
```json
{
  "average_cycle_length": 28,
  "average_period_length": 5,
  "birth_control_method": "pill",
  "pregnancy_mode": false,
  "pregnancy_start_date": null,
  "trying_to_conceive": true,
  "updated_at": "timestamp"
}
```

### Articles

#### Get Articles
```
GET /articles?category=fertility&limit=10&offset=0
```
Response:
```json
{
  "articles": [
    {
      "id": "uuid",
      "title": "Understanding Your Fertile Window",
      "content": "...",
      "category": "Fertility",
      "tags": ["ovulation", "conception", "fertility"],
      "author": "Dr. Jane Smith",
      "is_premium": false,
      "published_at": "timestamp"
    },
    {
      "id": "uuid",
      "title": "Advanced Fertility Tracking Methods",
      "content": "...",
      "category": "Fertility",
      "tags": ["basal-temperature", "cervical-mucus", "ovulation-tests"],
      "author": "Dr. John Doe",
      "is_premium": true,
      "published_at": "timestamp"
    }
  ],
  "total": 45,
  "limit": 10,
  "offset": 0
}
```

#### Get Article by ID
```
GET /articles/{article_id}
```
Response:
```json
{
  "id": "uuid",
  "title": "Understanding Your Fertile Window",
  "content": "...",
  "category": "Fertility",
  "tags": ["ovulation", "conception", "fertility"],
  "author": "Dr. Jane Smith",
  "is_premium": false,
  "published_at": "timestamp"
}
```

#### Bookmark Article
```
POST /articles/{article_id}/bookmark
```
Response:
```json
{
  "article_id": "uuid",
  "is_bookmarked": true,
  "bookmarked_at": "timestamp"
}
```

### Premium Subscription

#### Get Subscription Status
```
GET /subscription
```
Response:
```json
{
  "is_premium": false,
  "premium_expiry": null,
  "available_plans": [
    {
      "id": "monthly",
      "name": "Monthly Premium",
      "price": 9.99,
      "currency": "USD",
      "billing_period": "month"
    },
    {
      "id": "yearly",
      "name": "Yearly Premium",
      "price": 59.99,
      "currency": "USD",
      "billing_period": "year"
    }
  ]
}
```

#### Purchase Subscription
```
POST /subscription/purchase
```
Request Body:
```json
{
  "plan_id": "monthly",
  "payment_method_id": "pm_card_visa",
  "coupon_code": "WELCOME20"
}
```
Response:
```json
{
  "subscription_id": "sub_12345",
  "plan_id": "monthly",
  "is_premium": true,
  "premium_expiry": "2025-05-19T09:48:30Z",
  "next_billing_date": "2025-05-19T09:48:30Z"
}
```

#### Cancel Subscription
```
POST /subscription/cancel
```
Response:
```json
{
  "is_premium": true,
  "premium_expiry": "2025-05-19T09:48:30Z",
  "is_canceled": true,
  "will_renew": false
}
```

## Error Responses

All endpoints return standard HTTP status codes. Error responses follow this format:

```json
{
  "error": {
    "code": "invalid_credentials",
    "message": "The provided credentials are invalid",
    "status": 401
  }
}
```

Common error codes:
- `unauthorized`: Authentication required
- `forbidden`: Insufficient permissions
- `not_found`: Resource not found
- `validation_error`: Invalid request data
- `premium_required`: Premium subscription required for this feature
- `rate_limited`: Too many requests
